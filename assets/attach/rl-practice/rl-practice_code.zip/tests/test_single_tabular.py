"""表格法算法的单元测试（Q-learning / SARSA 更新与协议）。"""
import numpy as np

from rlpractice.algos.single.tabular import (
    qlearning_update, sarsa_update,
)
from rlpractice.envs.cliff import N_A, N_S, CliffEnv


def test_qlearning_vs_sarsa_targets_differ():
    """同一转移：max 与实际动作的目标不同（off/on-policy 的核心分歧）。"""
    Q = np.zeros((N_S, N_A))
    Q[5] = [0.4, 0.8, 0.2, 0.1]        # 下一状态价值：max=0.8（动作1）
    qlearning_update(Q, 3, 2, r=-0.04, s2=5, terminated=False, alpha=0.5, gamma=1.0)
    q_val = Q[3, 2]

    Q2 = np.zeros((N_S, N_A))
    Q2[5] = [0.4, 0.8, 0.2, 0.1]
    sarsa_update(Q2, 3, 2, r=-0.04, s2=5, a2=3, terminated=False, alpha=0.5, gamma=1.0)
    s_val = Q2[3, 2]

    # Q-learning: -0.04 + 0.8 = 0.76 → Q=0.38；SARSA: -0.04 + Q[5,3]=0.1 → Q=0.03
    assert abs(q_val - 0.38) < 1e-12
    assert abs(s_val - 0.03) < 1e-12


def test_terminated_does_not_bootstrap():
    Q = np.zeros((N_S, N_A))
    Q[5] = [9.0, 9.0, 9.0, 9.0]
    qlearning_update(Q, 3, 0, r=1.0, s2=5, terminated=True, alpha=1.0, gamma=1.0)
    assert abs(Q[3, 0] - 1.0) < 1e-12  # 只取 r，不看 Q[5]


def test_truncated_still_bootstraps():
    """人为步数上限是截断：连续任务照常外推（全项目统一约定）。"""
    Q = np.zeros((N_S, N_A))
    Q[5] = [0.6, 0.0, 0.0, 0.0]
    qlearning_update(Q, 3, 0, r=-0.04, s2=5, terminated=False, alpha=1.0, gamma=1.0)
    assert abs(Q[3, 0] - 0.56) < 1e-12


def test_epsilon_greedy_tie_breaks_to_action0():
    from rlpractice.algos.single.tabular import epsilon_greedy
    rng = np.random.default_rng(0)
    q = np.zeros(N_A)  # 全平局 → argmax 取 0（上）
    assert epsilon_greedy(q, eps=0.0, rng=rng) == 0
    # ε=1 时必随机
    assert all(0 <= epsilon_greedy(q, 1.0, rng) < N_A for _ in range(20))


def test_training_smoke_writes_artifacts(tmp_path):
    """端到端冒烟：日志、双模式评估、checkpoint 齐全。"""
    from rlpractice.common.runlog import RunLogger
    from rlpractice.algos.single.tabular import DEFAULTS, run_qlearning

    cfg = dict(DEFAULTS)
    cfg.update(algo="qlearning", env="cliff", seed=0, budget=3000,
               eval_every=1500, eval_episodes=4, test_episodes=10)
    with RunLogger(tmp_path, env="cliff", algo="qlearning", seed=0, config=cfg) as log:
        summary = run_qlearning(cfg, log)

    assert summary["env_steps"] >= 3000
    assert summary["test"]["greedy"]["n"] == 10
    assert summary["test"]["stochastic"]["n"] == 10
    assert (log.run_dir / "checkpoints" / "q_table.npz").exists()
    import numpy as np
    q = np.load(log.run_dir / "checkpoints" / "q_table.npz")["q"]
    assert q.shape == (N_S, N_A)
