"""策略梯度类（REINFORCE / A2C / PPO）的单元测试。"""
import numpy as np
import torch as th

from rlpractice.algos.single.pg import (
    A2C_DEFAULTS, PPO_DEFAULTS, REINFORCE_DEFAULTS,
    discounted_returns, gae, ppo_surrogate,
)


def test_discounted_returns_hand_calc():
    G = discounted_returns([0.0, 0.0, 1.0], gamma=0.9)
    assert np.allclose(G, [0.81, 0.9, 1.0])
    G2 = discounted_returns([1.0, -0.5], gamma=1.0)
    assert np.allclose(G2, [0.5, -0.5])


def test_gae_terminated_cuts_bootstrap():
    """真实终止：最后一步不 bootstrap，且 λ 链被切断。"""
    rewards = [1.0, 1.0]
    values = [0.5, 0.5]
    term = [False, True]        # 第 2 步终止
    end = [False, True]
    adv, rets = gae(rewards, values, term, end, last_value=99.0,
                    gamma=1.0, lam=1.0)
    # δ1 = 1 + 0 - 0.5 = 0.5（终止，next value 被屏蔽，last_value=99 不生效）
    # δ0 = 1 + 0.5 - 0.5 = 1.0；λ=1 → adv0 = δ0 + δ1 = 1.5
    assert abs(adv[1] - 0.5) < 1e-6
    assert abs(adv[0] - 1.5) < 1e-6
    assert np.allclose(rets, np.asarray(values) + adv)


def test_gae_truncation_bootstraps_but_cuts_chain():
    """截断：用 V(s_T) 做一步 bootstrap，但 λ 链不跨回合继续。"""
    rewards = [1.0]
    values = [0.4]
    adv, _ = gae(rewards, values, terminated_flags=[False], end_flags=[True],
                 last_value=2.0, gamma=0.9, lam=0.95)
    # δ = 1 + 0.9*2.0 - 0.4 = 2.4（截断允许 bootstrap）
    assert abs(adv[0] - 2.4) < 1e-6
    # 若链不切断（end=False）也相同因为只有一帧；用两帧验证切断点
    adv2, _ = gae([1.0, 1.0], [0.4, 0.4],
                  terminated_flags=[False, False], end_flags=[False, True],
                  last_value=2.0, gamma=0.9, lam=0.95)
    d1 = 1.0 + 0.9 * 2.0 - 0.4        # 末帧
    d0 = 1.0 + 0.9 * 0.4 - 0.4        # 下一帧价值取 V(s1)=0.4
    assert abs(adv2[1] - d1) < 1e-6
    assert abs(adv2[0] - (d0 + 0.9 * 0.95 * d1)) < 1e-6


def test_reinforce_baseline_advantage_mean_zero():
    """baseline 取均值时，回合内优势均值为 0（方差削减的定义）。"""
    G = np.array([1.0, 2.0, 3.0, 10.0])
    adv = G - G.mean()
    assert abs(adv.mean()) < 1e-9


def test_ppo_clip_gradient_zero_outside_interval():
    """裁剪的不对称性：adv>0 时只在 ratio>1+ε 处梯度归零，adv<0 时只在 ratio<1-ε。"""
    # adv>0、ratio 越上界 → 该样本梯度 0
    r_hi = th.tensor([1.5], requires_grad=True)
    ppo_surrogate(r_hi, th.tensor([1.0]), clip=0.2).sum().backward()
    assert abs(float(r_hi.grad[0])) < 1e-8
    # adv<0、ratio 越下界 → 该样本梯度 0
    r_lo = th.tensor([0.5], requires_grad=True)
    ppo_surrogate(r_lo, th.tensor([-1.0]), clip=0.2).sum().backward()
    assert abs(float(r_lo.grad[0])) < 1e-8
    # adv>0、ratio 越下界 → 仍在未裁剪分支，梯度推动 ratio 上升（非零）
    r_lo2 = th.tensor([0.5], requires_grad=True)
    ppo_surrogate(r_lo2, th.tensor([1.0]), clip=0.2).sum().backward()
    assert abs(float(r_lo2.grad[0]) + 1.0) < 1e-6


def test_ppo_clip_not_a_hard_constraint():
    """裁剪只影响损失，不改变 ratio 数值本身（对源讲义错误说法的对照测试）。"""
    ratio = th.tensor([1.5])                       # 越上界
    out = ppo_surrogate(ratio, th.tensor([1.0]), clip=0.2)
    # 损失取的是 1+ε 边界值 -1.2，但 ratio 仍是 1.5，没有被 clamp 回区间
    assert abs(float(out) + 1.2) < 1e-6
    assert float(ratio) == 1.5


def test_smoke_all_three(tmp_path):
    """端到端：三个算法极小预算跑通，产物与协议字段齐全。"""
    from rlpractice.common.runlog import RunLogger, read_run
    import importlib
    pg = importlib.import_module("rlpractice.algos.single.pg")

    for algo, defaults in (("reinforce", REINFORCE_DEFAULTS),
                           ("a2c", A2C_DEFAULTS),
                           ("ppo", PPO_DEFAULTS)):
        cfg = dict(defaults)
        cfg.update(algo=algo, env="cartpole", seed=0, budget=1200,
                   eval_every=600, eval_episodes=3, test_episodes=5)
        fn = pg.__dict__["run_" + algo] if "run_" + algo in pg.__dict__ else None
        assert fn is not None, algo
        with RunLogger(tmp_path, env="cartpole", algo=algo, seed=0, config=cfg) as log:
            summary = fn(cfg, log)
        run = read_run(log.run_dir)
        assert run["manifest"]["status"] == "completed"
        assert summary["test"]["n"] == 5
        assert len(run["episodes"]) > 0
        assert any(r["policy_mode"] == "greedy" for r in run["evals"])
        assert (log.run_dir / "checkpoints" / "final.pt").exists()
