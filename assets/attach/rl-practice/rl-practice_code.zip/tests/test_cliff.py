import numpy as np
import pytest

from rlpractice.envs.cliff import (
    ACTION_NAMES, CLIFF, GOAL, N_A, N_S, START, CliffEnv, to_cell, to_id,
)


def test_state_indexing_roundtrip():
    for r in range(4):
        for c in range(6):
            assert to_cell(to_id((r, c))) == (r, c)
    assert N_S == 24 and N_A == 4 and len(ACTION_NAMES) == 4


def test_wall_bounce_stays_put():
    env = CliffEnv(seed=0)
    s, _ = env.reset(seed=0)
    s2, r, term, trunc, info = env.step(0)  # 在 (3,0) 向上=行0? 不，(3,0)向上到(2,0)
    # 从起点 (3,0) 向左应撞墙保持原位
    s, _ = env.reset(seed=0)
    s2, r, term, trunc, info = env.step(2)  # 左
    assert to_cell(s2) == START
    assert r == -0.04 and not term and not trunc


def test_goal_terminates_with_reward():
    env = CliffEnv(seed=0)
    env.reset(seed=0)
    # 手工摆到 (2,5) 向下到目标
    env.state = to_id((2, 5))
    s, r, term, trunc, info = env.step(1)
    assert to_cell(s) == GOAL and r == 1.0 and term and info["success"]


def test_cliff_terminates_variant_behavior():
    env = CliffEnv(seed=0)
    env.reset(seed=0)
    # 起点向右一步就掉崖：这是本变体与 Sutton 标准版的关键差异
    s, r, term, trunc, info = env.step(3)
    assert to_cell(s) in CLIFF and r == -1.0 and term and info["fell"]
    assert not trunc


def test_truncation_is_not_termination():
    env = CliffEnv(max_steps=5, seed=0)
    env.reset(seed=0)
    term = trunc = False
    steps = 0
    while not (term or trunc):
        _, _, term, trunc, _ = env.step(0)  # 原地不动，永不终止
        steps += 1
    assert steps == 5 and not term and trunc


def test_shortest_path_return_is_076():
    """7 步贴崖路线：6×(-0.04) + 1.0 = 0.76。"""
    env = CliffEnv(seed=0)
    env.reset(seed=0)
    path = [0, 3, 3, 3, 3, 3, 1]  # 上，右×5，下 → 目标
    total, term = 0.0, False
    for a in path:
        _, r, term, trunc, _ = env.step(a)
        total += r
    assert term and abs(total - 0.76) < 1e-9


def test_long_path_return_is_068():
    """9 步绕远路线：8×(-0.04) + 1.0 = 0.68。"""
    env = CliffEnv(seed=0)
    env.reset(seed=0)
    path = [0, 0, 3, 3, 3, 3, 3, 1, 1]  # 上×2，右×5，下×2
    total, term = 0.0, False
    for a in path:
        _, r, term, trunc, _ = env.step(a)
        total += r
    assert term and abs(total - 0.68) < 1e-9


def test_reset_seed_is_reproducible():
    e1, e2 = CliffEnv(seed=7), CliffEnv(seed=7)
    seq1, seq2 = [], []
    for env, seq in ((e1, seq1), (e2, seq2)):
        env.reset(seed=123)
        for a in [3, 3, 0, 1, 2]:
            s, r, t, tr, info = env.step(a)
            seq.append((s, r, t, tr))
    assert seq1 == seq2


def test_invalid_action_raises():
    env = CliffEnv(seed=0)
    env.reset(seed=0)
    with pytest.raises(ValueError):
        env.step(9)
