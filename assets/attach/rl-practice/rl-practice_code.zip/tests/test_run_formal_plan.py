"""回归：run_formal 的「修复前旧运行不算完成」判定。

背景：COMA/MADDPG/IDDPG 的历史 completed 运行产生于实现修复之前。
如果编排脚本只按 budget 判断，重训时会把它们当成已完成而永久跳过。
"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path

PR = Path(__file__).resolve().parents[1]


def load_run_formal():
    spec = importlib.util.spec_from_file_location(
        "run_formal", PR / "scripts" / "run_formal.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_revision_aware_skip_rules():
    mod = load_run_formal()
    # 没有历史运行 → 要跑
    assert mod.needs_run(None, "maddpg", 62500) is True
    # 历史运行无修订（修复前）→ 必须重跑，即使预算一致
    assert mod.needs_run((62500, None), "maddpg", 62500) is True
    assert mod.needs_run((100000, None), "coma", 100000) is True
    # 已是修复版且预算一致 → 跳过
    assert mod.needs_run((62500, "policy-audit-v2"), "maddpg", 62500) is False
    # 预算不同 → 重跑
    assert mod.needs_run((50000, "policy-audit-v2"), "maddpg", 62500) is True
    # 未指定修订的算法（iql/vdn/qmix 等）照旧按预算判断
    assert mod.needs_run((100000, None), "iql", 100000) is False
    assert mod.needs_run((90000, None), "iql", 100000) is True


def test_done_runs_reads_revision(tmp_path, monkeypatch):
    mod = load_run_formal()
    d = tmp_path / "nav2d" / "maddpg" / "seed0_20260101-000000"
    d.mkdir(parents=True)
    (d / "manifest.json").write_text(json.dumps({
        "env": "nav2d", "algo": "maddpg", "seed": 0, "status": "completed",
        "config": {"budget": 62500},
    }, ensure_ascii=False), encoding="utf-8")
    # 未完成的运行不计数
    d2 = tmp_path / "nav2d" / "maddpg" / "seed1_20260101-000000"
    d2.mkdir(parents=True)
    (d2 / "manifest.json").write_text(json.dumps({
        "env": "nav2d", "algo": "maddpg", "seed": 1, "status": "failed",
        "config": {"budget": 62500},
    }, ensure_ascii=False), encoding="utf-8")

    monkeypatch.setattr(mod, "RUNS", tmp_path)
    got = mod.done_runs()
    assert got[("nav2d", "maddpg", 0)] == (62500, None)
    assert ("nav2d", "maddpg", 1) not in got
    # 关键断言：历史运行必须触发重跑
    assert mod.needs_run(got[("nav2d", "maddpg", 0)], "maddpg", 62500) is True
