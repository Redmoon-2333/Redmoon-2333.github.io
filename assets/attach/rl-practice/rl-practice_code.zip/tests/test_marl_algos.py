"""MARL 算法的单元测试：TD 语义、QMIX 性质、消融隔离、COMA 优势。"""
import numpy as np
import torch as th

from rlpractice.algos.marl.comm import CommQNet
from rlpractice.algos.marl.policy import coma_advantage, counterfactual_baseline
from rlpractice.algos.marl.value import QMixer, td_target


# ------------------------------------------------------------------ TD 语义
def test_td_target_terminated_masks_next_value():
    rew = th.tensor([1.0, 1.0])
    don = th.tensor([1.0, 0.0])
    nxt = th.tensor([100.0, 100.0])
    out = td_target(rew, don, gamma=0.95, next_values=nxt, mode="element")
    assert float(out[0]) == 1.0                     # terminated：只剩 r
    assert abs(float(out[1]) - (1 + 0.95 * 100)) < 1e-6   # 未终止（含截断）：外推


def test_td_target_joint_vs_per_agent():
    rew = th.tensor([0.5])
    don = th.tensor([0.0])
    nxt = th.tensor([[1.0, 2.0]])
    # joint：r 只加一次 → 0.5 + (1+2)
    joint = td_target(rew, don, gamma=1.0, next_values=nxt, mode="joint")
    assert joint.shape == (1,)
    assert abs(float(joint[0]) - 3.5) < 1e-6
    # per_agent：r 广播到每个智能体 → [0.5+1, 0.5+2]
    per = td_target(rew, don, gamma=1.0, next_values=nxt, mode="per_agent")
    assert per.shape == (1, 2)
    assert np.allclose(per.numpy(), [[1.5, 2.5]])


# ------------------------------------------------------------------ QMIX
def test_qmix_is_monotone_in_each_agent_q():
    th.manual_seed(0)
    mixer = QMixer(n_agents=2, state_dim=5, hidden=16)
    qs = th.randn(8, 2)
    st = th.randn(8, 5)
    base = mixer(qs, st)
    for i in range(2):
        bumped = qs.clone()
        bumped[:, i] += 1.0
        assert (mixer(bumped, st) >= base - 1e-5).all(), f"agent {i} 破坏单调性"


def test_qmix_can_represent_negative_team_value():
    """源实现的硬伤：ReLU 偏置让 Q_tot ≥ 0，本版必须能输出负值。"""
    th.manual_seed(0)
    mixer = QMixer(n_agents=2, state_dim=5, hidden=16)
    out = mixer(th.full((4, 2), -50.0), th.randn(4, 5))
    assert (out < 0).all()


# --------------------------------------------------- 通信消融：等深度等参数
def test_commnet_and_nomsg_have_identical_parameters():
    a = CommQNet(obs_dim=3, n_actions=3, n_agents=2, hidden=32, rounds=2,
                 use_message=True)
    b = CommQNet(obs_dim=3, n_actions=3, n_agents=2, hidden=32, rounds=2,
                 use_message=False)
    assert sum(p.numel() for p in a.parameters()) == sum(p.numel() for p in b.parameters())


def test_nomsg_output_independent_of_injected_messages():
    th.manual_seed(0)
    net = CommQNet(3, 3, 2, hidden=16, rounds=2, use_message=False)
    obs = th.randn(1, 2, 3)
    m1, m2 = th.randn(1, 2, 16), th.randn(1, 2, 16)
    y1, y2 = net(obs, messages=m1), net(obs, messages=m2)
    assert th.allclose(y1, y2)                      # 消息被完全忽略

    net2 = CommQNet(3, 3, 2, hidden=16, rounds=2, use_message=True)
    z1, z2 = net2(obs, messages=m1), net2(obs, messages=m2)
    assert not th.allclose(z1, z2)                  # 通信版对消息敏感


def test_commnet_messages_come_from_teammates_previous_state():
    """同步轮次：聚合消息 = 队友广播的均值（去掉自己）。"""
    th.manual_seed(0)
    net = CommQNet(3, 3, 2, hidden=8, rounds=1, use_message=True)
    obs = th.randn(1, 2, 3)
    with th.no_grad():
        h = net.enc(obs)
        b = net.bcast(h)
        c_manual = (b.sum(1, keepdim=True) - b) / 1.0   # 两 agent：除以 n-1=1
        h0 = h + net.cells[0](th.cat([h, c_manual], dim=-1))
        y_manual = net.head(h0)
    assert th.allclose(net(obs), y_manual, atol=1e-6)


# ------------------------------------------------------------------ COMA
def test_counterfactual_baseline_hand_calc():
    pi = th.tensor([[0.2, 0.3, 0.5]])
    q_alt = th.tensor([[1.0, 2.0, 4.0]])
    base = counterfactual_baseline(pi, q_alt)
    assert abs(float(base[0]) - (0.2 * 1 + 0.3 * 2 + 0.5 * 4)) < 1e-6


def test_coma_advantage_is_detached():
    q_taken = th.tensor([1.0], requires_grad=True)
    q_alt = th.tensor([[0.5, 1.0, 2.0]], requires_grad=True)
    pi = th.softmax(th.randn(1, 3, requires_grad=True), dim=-1)
    adv = coma_advantage(q_taken, q_alt, pi)
    assert not adv.requires_grad                    # 梯度不回流 critic
    adv.sum().backward() if adv.requires_grad else None
    # 数值核对
    base = counterfactual_baseline(pi.detach(), q_alt.detach())
    assert th.allclose(adv, (q_taken.detach() - base))


# ------------------------------------------------------------------ 冒烟
def test_iql_smoke(tmp_path):
    from rlpractice.algos.marl.value import DEFAULTS, run_iql
    from rlpractice.common.runlog import RunLogger, read_run
    cfg = dict(DEFAULTS)
    cfg.update(algo="iql", env="corridor", seed=0, budget=800,
               eval_every=400, eval_episodes=3, test_episodes=5, warmup=200)
    with RunLogger(tmp_path, env="corridor", algo="iql", seed=0, config=cfg) as log:
        summary = run_iql(cfg, log)
    run = read_run(log.run_dir)
    assert run["manifest"]["status"] == "completed"
    assert summary["test"]["n"] == 5
    assert (log.run_dir / "checkpoints" / "final.pt").exists()


def test_commnet_smoke(tmp_path):
    from rlpractice.algos.marl.comm import run_commnet
    from rlpractice.common.runlog import RunLogger
    import importlib
    mod = importlib.import_module("rlpractice.algos.marl.comm")
    cfg = dict(mod.DEFAULTS)
    cfg.update(algo="commnet", env="riddle", seed=0, budget=600,
               eval_every=300, eval_episodes=3, test_episodes=5, warmup=150)
    with RunLogger(tmp_path, env="riddle", algo="commnet", seed=0, config=cfg) as log:
        summary = run_commnet(cfg, log)
    assert summary["test"]["n"] == 5
    assert summary["n_params"] > 0
