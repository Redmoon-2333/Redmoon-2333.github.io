import numpy as np

from rlpractice.algos.marl.envs import (
    CorridorEnv, Nav2D, RiddleEnv, eval_marl, make_marl_env,
)


# ---------------------------------------------------------------- 走廊
def test_corridor_success_terminates():
    env = CorridorEnv(seed=0)
    env.reset(seed=0)
    env.pos = np.array([1, 3])
    env.door_open = True
    obs, r, term, trunc, info = env.step([1, 0])  # agent0 → 0（目标）
    assert term and not trunc
    assert info["success"] and abs(r - 9.9) < 1e-9  # -0.1 + 10


def test_corridor_timeout_is_truncation():
    env = CorridorEnv(seed=0)
    env.reset(seed=0)
    env.t = env.MAX_STEPS - 1
    _, r, term, trunc, info = env.step([0, 0])
    assert trunc and not term and not info["success"]


def test_corridor_collision_penalty():
    env = CorridorEnv(seed=0)
    env.reset(seed=0)
    env.door_open = True
    env.pos = np.array([3, 5])
    env.SLIP_P = 0.0
    _, r, term, trunc, info = env.step([2, 1])  # 双双进入 4 号格
    assert abs(r - (-0.3)) < 1e-9  # -0.1 - 0.2
    assert info["collided"] and not term


def test_corridor_hold_opens_door_after_two_steps():
    env = CorridorEnv(seed=0)
    env.reset(seed=0)
    env.SLIP_P = 0.0
    env.pos = np.array([2, 6])  # 双双踩住开关
    env.step([0, 0])
    assert not env.door_open and env.hold_count == 1
    env.step([0, 0])
    assert env.door_open and env.hold_count == 2


def test_corridor_slip_forces_stay():
    env = CorridorEnv(seed=0)
    env.reset(seed=0)
    env.SLIP_P = 1.0
    env.pos = np.array([1, 5])
    env.step([1, 2])  # 想走，但 100% 打滑
    assert list(env.pos) == [1, 5]


def test_corridor_obs_and_state_shapes():
    env = CorridorEnv(seed=0)
    obs, _ = env.reset(seed=0)
    assert obs.shape == (2, 5) and obs.dtype == np.float32
    assert env.global_state().shape == (5,)


# ---------------------------------------------------------------- 谜题
def test_riddle_correct_answer_terminates_success():
    env = RiddleEnv(seed=0)
    env.reset(seed=0)
    env.target = 4
    env.pos = np.array([1, 5])
    _, r, term, trunc, info = env.step([0, 1])  # agent1 左移到 4
    assert term and info["success"] and not info["fell"]
    assert abs(r - 9.9) < 1e-9


def test_riddle_wrong_answer_terminates_fail():
    env = RiddleEnv(seed=0)
    env.reset(seed=0)
    env.target = 6
    env.pos = np.array([1, 5])
    _, r, term, trunc, info = env.step([0, 1])  # 走到 4（错）
    assert term and info["fell"] and not info["success"]
    assert abs(r - (-5.1)) < 1e-9


def test_riddle_timeout_is_truncation():
    env = RiddleEnv(seed=0)
    env.reset(seed=0)
    env.t = env.MAX_STEPS - 1
    _, _, term, trunc, info = env.step([0, 0])
    assert trunc and not term and not info["success"] and not info["fell"]


def test_riddle_asymmetric_information():
    env = RiddleEnv(seed=0)
    obs, _ = env.reset(seed=0)
    env.target = 6
    obs = env._obs()
    assert obs[0, 2] == 1.0   # 智能体 0 看得见答案
    assert obs[1, 2] == 0.5   # 智能体 1 未知
    env.target = 4
    assert env._obs()[0, 2] == 0.0


def test_riddle_agent0_cannot_reach_switches():
    env = RiddleEnv(seed=0)
    env.reset(seed=0)
    env.pos = np.array([1, 5])
    for _ in range(6):
        _, _, term, trunc, _ = env.step([2, 0])  # agent0 一直向右
        if term or trunc:
            break
    assert env.pos[0] < env.WALL  # 3 号墙挡住，永远在左侧


# ---------------------------------------------------------------- 2D 导航
def test_nav_never_terminates_only_truncates():
    env = Nav2D(seed=0)
    env.reset(seed=0)
    term = trunc = False
    steps = 0
    while not (term or trunc):
        _, _, term, trunc, _ = env.step(np.zeros((2, 2)))
        steps += 1
    assert not term and trunc and steps == env.MAX_STEPS


def test_nav_actions_are_clipped_before_physics():
    env = Nav2D(seed=0)
    env.reset(seed=0)
    env.step(np.full((2, 2), 5.0))
    assert np.abs(env.agent_vel).max() <= 0.1 + 1e-9  # 0.9*0 + clip(5)*0.1


def test_nav_success_requires_covering_both_landmarks():
    env = Nav2D(seed=0)
    env.reset(seed=0)
    env.agent_pos = env.landmarks.copy()  # 一一对应
    env.t = env.MAX_STEPS - 1
    _, _, term, trunc, info = env.step(np.zeros((2, 2)))
    assert trunc and info["success"]

    env2 = Nav2D(seed=0)
    env2.reset(seed=0)
    env2.agent_pos = np.array([[-1.0, -1.0], [-1.0, -1.0]])  # 挤在一起，远离地标
    env2.t = env2.MAX_STEPS - 1
    _, _, _, trunc, info = env2.step(np.zeros((2, 2)))
    assert trunc and not info["success"]


# ---------------------------------------------------------------- 评估协议
def test_eval_marl_reproducible_and_isolated():
    def act(obs):
        return [0, 0]

    seeds = [10000, 10001]
    r1 = eval_marl("corridor", act, seeds, max_steps=40)
    r2 = eval_marl("corridor", act, seeds, max_steps=40)
    assert [x["return"] for x in r1] == [x["return"] for x in r2]
    assert [x["env_seed"] for x in r1] == seeds
    assert set(r1[0]) >= {"env_seed", "return", "length", "success", "fell", "truncated"}


def test_make_marl_env_registry():
    for name, cls in (("corridor", CorridorEnv), ("riddle", RiddleEnv), ("nav2d", Nav2D)):
        assert isinstance(make_marl_env(name, seed=1), cls)
