"""Audit regressions: exercise the actual update loop, not only helpers."""
import numpy as np
import pytest
import torch as th

from rlpractice.algos.marl import policy
from rlpractice.common.runlog import RunLogger


def test_coma_expectation_is_outside_nonlinear_critic():
    class Nonlinear(th.nn.Module):
        def forward(self, states, actions):
            return actions.square().sum(-1)
    probs = th.full((2, 2, 3), 1 / 3)
    states = th.zeros(2, 5)
    value = policy.joint_policy_value(Nonlinear(), states, probs)
    assert th.allclose(value, th.full((2,), 2.0))
    assert not th.allclose(value, Nonlinear()(states, probs.flatten(1)))


def test_sampling_uses_only_explicit_rng():
    logits = [th.tensor([0.0, 0.2, 0.7])] * 2
    before = th.get_rng_state().clone()
    a = np.random.default_rng(42)
    b = np.random.default_rng(42)
    first = [policy.sample_categorical(logits, a) for _ in range(20)]
    th.rand(123)
    second = [policy.sample_categorical(logits, b) for _ in range(20)]
    assert np.array_equal(first, second)
    th.set_rng_state(before)
    policy.sample_categorical(logits, a)
    assert th.equal(before, th.get_rng_state())


@pytest.mark.parametrize('mode', ['ctde', 'indep'])
@pytest.mark.parametrize('batch_size', [1, 4])
def test_both_ddpg_actors_learn_and_targets_are_vectors(tmp_path, monkeypatch, mode, batch_size):
    captured = []
    original_mlp = policy.mlp
    def record_mlp(*args, **kwargs):
        net = original_mlp(*args, **kwargs)
        captured.append((net, [p.detach().clone() for p in net.parameters()]))
        return net
    monkeypatch.setattr(policy, 'mlp', record_mlp)
    original_loss = th.nn.functional.smooth_l1_loss
    calls = []
    def checked_loss(pred, target, *args, **kwargs):
        assert pred.shape == target.shape == (batch_size,)
        calls.append(True)
        return original_loss(pred, target, *args, **kwargs)
    monkeypatch.setattr(th.nn.functional, 'smooth_l1_loss', checked_loss)
    cfg = dict(policy.DEFAULTS, algo='maddpg' if mode == 'ctde' else 'iddpg',
               env='nav2d', seed=0, budget=16, warmup=4, hidden=8,
               batch_size=batch_size, eval_every=16, eval_episodes=1, test_episodes=2)
    with RunLogger(tmp_path, env='nav2d', algo=cfg['algo'], seed=0, config=cfg) as log:
        result = policy.run_maddpg_like(mode, cfg, log)
    assert calls and result['test']['n'] == 2
    for net, initial in captured[:2]:
        assert any(not th.equal(old, new) for old, new in zip(initial, net.parameters()))
        assert all(p.requires_grad for p in net.parameters())


def test_coma_loop_smoke(tmp_path):
    cfg = dict(policy.DEFAULTS, algo='coma', env='corridor', seed=0,
               budget=80, hidden=8, batch_episodes=1, critic_epochs=1,
               eval_every=80, eval_episodes=1, test_episodes=2)
    with RunLogger(tmp_path, env='corridor', algo='coma', seed=0, config=cfg) as log:
        result = policy.run_coma(cfg, log)
    assert result['env_steps'] == 80
    assert all(result['test'][mode]['n'] == 2 for mode in ('greedy', 'stochastic'))
