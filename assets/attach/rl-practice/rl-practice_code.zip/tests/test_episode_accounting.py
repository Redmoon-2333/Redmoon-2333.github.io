"""回归：跨 rollout 分批算法的局长记账必须闭合（sum(length) == env_steps）。

背景：历史 PPO 运行在每个 rollout 边界把进行中回合的已累计长度/回报清零但不落盘，
导致 episodes.csv 局长和比预算少 4164–4927 步（env 预算本身已走满）。
当前 pg.py 跨 rollout 累计（ep_ret/ep_len 在回合结束才清零），本测试锁定该行为：
- PPO 与 A2C 用小预算跑过多个 rollout 边界；
- 断言每个相邻行 env_steps 增量恰等于该行 length（无边界丢弃）；
- 断言 sum(length) == env_steps == budget。
"""
from __future__ import annotations

import csv
from pathlib import Path

import pytest

from rlpractice.common.runlog import RunLogger
from rlpractice.algos.single.pg import PPO_DEFAULTS, A2C_DEFAULTS, run_ppo, run_a2c


def _run(tmp_path, run_fn, defaults, rollout, budget, seed=7):
    cfg = dict(defaults)
    cfg.update(seed=seed, budget=budget, rollout=rollout,
               eval_every=budget + 1, eval_episodes=2, test_episodes=2,
               val_seed_base=10000, test_seed_base=20000)
    cfg["epochs"] = 1          # 加速：记账测试不关心优化轮数
    log = RunLogger(tmp_path, env="cartpole",
                    algo="ppo" if run_fn is run_ppo else "a2c",
                    seed=seed, config=cfg)
    run_fn(cfg, log)
    rows = list(csv.DictReader((log.run_dir / "episodes.csv").open(encoding="utf-8")))
    return rows


def _assert_closed(rows, budget):
    assert rows, "无 episode 记录"
    prev = 0
    for r in rows:
        delta = int(r["env_steps"]) - prev
        assert delta == int(r["length"]), (
            f"env_steps 增量 {delta} != length {int(r['length'])} @ep{r['episode']}："
            "rollout 边界丢弃了进行中回合的累计步数")
        prev = int(r["env_steps"])
    assert sum(int(r["length"]) for r in rows) == budget
    assert prev == budget


def test_ppo_episode_accounting_closes_across_rollouts(tmp_path):
    # budget=700 跨过 1 个完整 rollout(64) 边界多次；episode 平均 20-40 步，
    # 必然有回合横跨边界——旧代码在这里丢步。
    rows = _run(tmp_path, run_ppo, PPO_DEFAULTS, rollout=64, budget=700)
    _assert_closed(rows, 700)
    # 确认测试确实覆盖了跨边界回合（有多个 rollout）
    assert int(rows[-1]["env_steps"]) == 700


def test_a2c_episode_accounting_closes_across_rollouts(tmp_path):
    rows = _run(tmp_path, run_a2c, A2C_DEFAULTS, rollout=32, budget=700)
    _assert_closed(rows, 700)
