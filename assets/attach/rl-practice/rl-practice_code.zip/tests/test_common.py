import json
from pathlib import Path

from rlpractice.common.evaluate import evaluate_policy, held_out_seeds, summarize
from rlpractice.common.runlog import RunLogger, find_runs, read_run, source_sha256
from rlpractice.common.stats import first_threshold_crossing, mean, moving_average, std_sample
from rlpractice.envs.cliff import CliffEnv


def test_runlogger_roundtrip(tmp_path: Path):
    log = RunLogger(tmp_path, env="cliff", algo="qlearning", seed=3,
                    config={"budget": 100})
    log.episode(0, 0.5, 10, 10, 1, True, False)
    log.episode(1, -0.2, 20, 30, 2, False, True)
    recs = evaluate_policy(CliffEnv(seed=0), lambda s: 3, held_out_seeds(500, 5), 100)
    log.evaluate(step=100, policy_mode="greedy", records=recs)
    log.finish("completed")

    run = read_run(log.run_dir)
    man = run["manifest"]
    assert man["status"] == "completed" and man["seed"] == 3
    assert man["source_sha256"] == source_sha256()
    assert man["config"]["budget"] == 100
    assert len(run["episodes"]) == 2
    assert run["episodes"][1]["truncated"] == 1 and run["episodes"][1]["terminated"] == 0
    assert len(run["evals"]) == 5
    assert all(r["policy_mode"] == "greedy" for r in run["evals"])

    found = find_runs(tmp_path, env="cliff", algo="qlearning")
    assert log.run_dir in found


def test_failed_run_records_status(tmp_path: Path):
    try:
        with RunLogger(tmp_path, env="cliff", algo="boom", seed=0, config={}) as log:
            raise RuntimeError("training exploded")
    except RuntimeError:
        pass
    man = json.loads((log.run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert man["status"] == "failed"
    assert "RuntimeError" in man["note"]


def test_eval_isolated_from_training_rng():
    """评估不改变环境/训练 RNG 状态。"""
    env = CliffEnv(seed=11)
    env.reset(seed=11)
    before = env.rng.bit_generator.state
    evaluate_policy(env, lambda s: 3, held_out_seeds(900, 10), 50)
    # 评估用 reset(seed=...) 重设了 RNG，这里验证评估本身可重复
    env2 = CliffEnv(seed=11)
    r1 = evaluate_policy(env2, lambda s: 3, held_out_seeds(900, 10), 50)
    env3 = CliffEnv(seed=99)
    r2 = evaluate_policy(env3, lambda s: 3, held_out_seeds(900, 10), 50)
    assert [x["return"] for x in r1] == [x["return"] for x in r2]
    assert env.rng.bit_generator.state is not None and before is not None


def test_summarize_uses_raw_records():
    recs = [{"return": 1.0, "length": 5, "success": True, "fell": False, "truncated": False},
            {"return": -1.0, "length": 7, "success": False, "fell": True, "truncated": False}]
    s = summarize(recs)
    assert s["n"] == 2 and s["success_rate"] == 0.5 and s["fell_rate"] == 0.5
    assert abs(s["return_mean"]) < 1e-12
    assert abs(s["return_std"] - 1.41421356) < 1e-6  # 样本 SD，不是 SEM


def test_threshold_crossing_uses_window_endpoint():
    x = [0.0] * 10 + [5.0] * 20
    idx = first_threshold_crossing(x, threshold=1.0, window=5, mode="above")
    assert idx is not None
    # 窗口满员的第一个判定位置：i=4 时均值仍含 0；i=9 时窗口为 [0..9] 全 0 → 不过；
    # i=10 起窗口含 5 → 首个满足 i+1>=window 且均值>=1 的位置是 10
    assert idx == 10
    assert first_threshold_crossing([0.0] * 30, 1.0, window=5) is None  # censored


def test_moving_average_and_stats():
    ma = moving_average([1, 2, 3, 4], 2)
    assert ma == [1.0, 1.5, 2.5, 3.5]
    assert abs(mean([1, 2, 3]) - 2.0) < 1e-12
    assert abs(std_sample([2, 4, 4, 4, 5, 5, 7, 9]) - 2.13809) < 1e-4
