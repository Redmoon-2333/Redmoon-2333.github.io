# rl-practice — 强化学习实践系列的可复现实验项目

本项目支撑博客「强化学习」实践专题的 12 篇文章：从表格方法到 DQN／策略梯度／PPO，
再到六个多智能体机制演示，以及实验方法论与研究版图。

**定位声明**：多智能体部分是 *三个自定义小环境上的六个教学机制演示*，
不是对原论文的完整复现，也不用于宣称算法优劣排名。所有正文数字必须能追溯到
本项目的原始日志与 checkpoint。

## 环境

PyTorch 相关代码统一使用专属 conda 环境 `pytorch-gpu`：

| 组件 | 版本 |
|---|---|
| Python | 3.12.12（`C:\Users\lenovo\anaconda3\envs\pytorch-gpu`） |
| PyTorch | 2.10.0+cu128（本机 RTX 4060 可用；本项目实验统一在 CPU 上跑，保证可复现性） |
| NumPy | 2.4.1 |
| Matplotlib / Seaborn | 3.10.8 / 0.13.2 |
| Gymnasium | 1.3.0 |
| pytest | 9.1.1 |
| pandas / SciPy / pypdf | 3.0.0 / 1.16.3 / 6.19.0 |

> 环境修复记录（内部）：该环境曾因 `torch\lib\libiomp5md.dll` 与 conda
> `Library\bin\libiomp5md.dll` 两份 Intel OpenMP 运行时冲突而无法 `import torch`。
> 已将 conda 侧副本改名为 `libiomp5md.dll.disabled-omp-conflict` 保留备份，
> torch 自带副本可正常加载，CUDA 与 scipy 均验证通过。**未使用
> `KMP_DUPLICATE_LIB_OK=TRUE` 掩盖问题。**

## 运行

```powershell
$py = 'C:\Users\lenovo\anaconda3\envs\pytorch-gpu\python.exe'
& $py -m pytest tests -q                 # 单元测试
& $py -m rlpractice.train --algo qlearning --env cliff --seed 0 --budget 100000
& $py -m rlpractice.figures              # 只读 runs/ 生成图表，绝不训练
```

## 数据 schema

每次运行写入 `runs/<env>/<algo>/seed<k>_<时间戳>/`：

- `manifest.json`：algo、env、seed、预算、完整配置、依赖版本、源码 SHA256、起止时间、状态
  （`running` / `completed` / `failed`）、失败原因。
- `episodes.csv`：`episode,return,length,env_steps,updates,elapsed_s,terminated,truncated`
- `evals.csv`：`step,policy_mode,episode,seed,env_seed,return,length,success,fell,truncated`
- `checkpoints/`：最终策略（含训练 RNG 状态）与中途 checkpoint。

规则：训练、评估、绘图三者分离；绘图只消费 `runs/` 里的原始产物；
不同配置不会覆盖同名结果；失败运行保留原始日志并标记。

**配置版本**：DQN 与 A2C 的初版配置在 100k 预算内未学会 CartPole，已冻结为
v2（DQN：ε 10k 衰减、batch 32、target 500；A2C：rollout 32、lr 1e-3、
`ent_coef` 0.001、`grad_clip` 5.0、关闭批内优势归一化）并以 5 种子重跑；
v1 运行归档在 `runs_v1_cartpole/`（位于 `runs/` 根之外，不参与聚合）。
调参探针接触过原测试种子，故 CartPole 四算法的正文数字取
`scripts/final_eval.py` 在 **30000–30099 新种子**上的一次性复评
（各 run 的 `final_eval.csv`）。

## 实验预算（正式组）

| 实验组 | 每方法、每训练种子的环境步预算 |
|---|---:|
| Q-learning / SARSA（cliff 变体） | 100,000（单回合 ≤100 步） |
| DQN / REINFORCE / A2C / PPO（CartPole） | 100,000 |
| IQL / VDN / QMIX / COMA（走廊） | 100,000 联合步 |
| 通信 / 等深度零消息 / IQL（开关谜题） | 50,000 联合步 |
| MADDPG / IDDPG（2D 导航） | 62,500 联合步 |

训练种子 0–4；每 10% 预算做一次 20 局验证（独立验证种子）；
最终模型在保留的 100 个测试种子上评估。验证与测试不参与训练，也不用于挑 checkpoint。

## 与源项目的关系

环境规则、网络结构、回放与反事实枚举等逻辑移植自
`杜枭的课题\前期的研究\02_代码复现` 与 `强化学习入门\code`，原目录保持不动。
移植时修正了以下已确认问题（详见正文与 `tests/`）：

1. QMIX 混合网络输出被迫非负 → 无法表示负团队价值；
2. COMA 用陈旧回放 + ε 混合动作却按当前策略 log-prob 更新 actor → 无校正的 off-policy；
3. MADDPG／IDDPG 的 critic 目标混用两个 target critic 的平均值；
4. 通信消融同时去掉通信与网络深度 → 归因混淆；同步轮次未实现；
5. 环境把真实终止与时间上限截断合并成一个 `done`；
6. 绘图脚本写死“快 4 倍”等结论，且绘图时重新训练 IQL；
7. 评估种子/调度不一致，缺少统一的保留测试协议。

2026-09 审计又确认并修复了四处实现缺陷（详见正文第 8/9/11 章与
`tests/test_policy_regressions.py`）：

8. MADDPG／IDDPG 的 critic 预测 `[B,1]` 与 reward/done `[B]` 广播成 `[B,B]` 目标；
9. actor 冻结/解冻发生在 forward 之后 → 第二个 actor 从不获得梯度（10 个历史
   Nav checkpoint 的 actor1 与初始化逐元素相同）；
10. COMA 用 $Q(s,\mathbb{E}[\mathrm{onehot}])$ 近似 $\mathbb{E}[Q(s,a)]$ → 改为枚举联合动作的精确期望；
11. COMA 随机评估忽略显式 RNG → 改用按评估种子派生的独立 NumPy RNG。

修复前的 COMA/MADDPG/IDDPG 正式运行不再作为算法对照证据；重新得出结论需按同协议重训。

## 目录

```
rlpractice/
  common/       注册表、运行日志、评估协议、统计工具
  envs/         cliff 环境（terminating 变体，见正文）
  algos/single/ DQN、REINFORCE、A2C、PPO（+ 表格法）
  algos/marl/   三环境 + IQL/VDN/QMIX/COMA/MADDPG/通信
  train.py      统一 CLI
  figures/      纯读取绘图与数据摘要
tests/          单元测试（边界、目标、掩码、消融隔离、策略回归）
runs/           原始日志与 checkpoint（不入库）
figures_out/    图表输出（PNG 300 DPI + SVG/PDF）
```
