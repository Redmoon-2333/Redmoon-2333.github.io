"""冻结配置后的一次性最终复评（CartPole 组）。

背景：超参调优阶段的探针曾查看过原测试种子（20000+）的结果，构成轻度
评估集污染。配置冻结后，本脚本加载各次正式运行的 checkpoint，在**从未
参与任何调参的新测试种子 30000–30099** 上做一次性评估，结果写入
`<run_dir>/final_eval.csv` 并登记进 manifest 的 `final_eval` 字段。
正文引用的 CartPole 数字以复评结果为准；第 11 章如实披露这一过程。

只读评估：不训练、不改模型、不回写训练日志。
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import torch as th  # noqa: E402

from rlpractice.algos.single.dqn import build_net, make_env  # noqa: E402
from rlpractice.algos.single.pg import ActorCritic  # noqa: E402
from rlpractice.common.evaluate import held_out_seeds  # noqa: E402
from rlpractice.common.runlog import find_runs  # noqa: E402
from rlpractice.common.stats import mean, std_sample  # noqa: E402

FRESH_SEED_BASE = 30000
N_EPISODES = 100
MAX_STEPS = 600
ALGOS = ("dqn", "reinforce", "a2c", "ppo")


def load_policy(algo: str, ckpt_path: Path, config: dict):
    hidden = int(config.get("hidden", 128))
    blob = th.load(ckpt_path, map_location="cpu", weights_only=False)
    if algo == "dqn":
        net = build_net(hidden)
        net.load_state_dict(blob["policy"])
        return lambda obs: int(net(th.as_tensor(obs[None], dtype=th.float32)).argmax(-1).item())
    if algo == "reinforce":
        model = th.nn.Sequential(
            th.nn.Linear(4, hidden), th.nn.ReLU(),
            th.nn.Linear(hidden, hidden), th.nn.ReLU(),
            th.nn.Linear(hidden, 2))
        model.load_state_dict(blob["state_dict"])
        return lambda obs: int(model(th.as_tensor(obs[None], dtype=th.float32)).argmax(-1).item())
    # a2c / ppo
    model = ActorCritic(hidden)
    model.load_state_dict(blob["state_dict"])
    return lambda obs: int(model(th.as_tensor(obs[None], dtype=th.float32))[0].argmax(-1).item())


def main() -> int:
    runs_root = PR / "runs"
    jobs = []
    for algo in ALGOS:
        for d in find_runs(runs_root, env="cartpole", algo=algo):
            if (d / "final_eval.csv").exists():
                continue
            jobs.append(d)
    if not jobs:
        print("[skip] 所有 CartPole 运行均已完成复评")
        return 0

    print(f"[plan] 待复评 {len(jobs)} 个运行，种子 {FRESH_SEED_BASE}–{FRESH_SEED_BASE + N_EPISODES - 1}")
    for d in jobs:
        man = json.loads((d / "manifest.json").read_text(encoding="utf-8"))
        algo, config = man["algo"], man["config"]
        act = load_policy(algo, d / "checkpoints" / "final.pt", config)
        env = make_env()
        records = []
        for s in held_out_seeds(FRESH_SEED_BASE, N_EPISODES):
            obs, _ = env.reset(seed=s)
            ret, length, term, trunc = 0.0, 0, False, False
            info = {}
            while not (term or trunc) and length < MAX_STEPS:
                obs, r, term, trunc, info = env.step(act(obs))
                ret += r
                length += 1
            records.append({
                "env_seed": s, "return": ret, "length": length,
                "success": bool(info.get("success", False)),
                "fell": bool(info.get("fell", False)),
                "truncated": bool(trunc and not term),
            })
        with open(d / "final_eval.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(records[0]))
            w.writeheader()
            w.writerows(records)
        rets = [r["return"] for r in records]
        man["final_eval"] = {
            "seed_base": FRESH_SEED_BASE, "n": N_EPISODES, "policy_mode": "greedy",
            "return_mean": round(mean(rets), 6),
            "return_sd": round(std_sample(rets), 6),
            "success_rate": round(mean([r["success"] for r in records]), 4),
            "fell_rate": round(mean([r["fell"] for r in records]), 4),
            "note": "冻结配置后的一次性复评；探针阶段未接触该种子段",
        }
        (d / "manifest.json").write_text(
            json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"[done] {algo}/seed{man['seed']}: "
              f"return {man['final_eval']['return_mean']:.1f} "
              f"± {man['final_eval']['return_sd']:.1f}, "
              f"success {100 * man['final_eval']['success_rate']:.1f}%")
    return 0


PR = Path(__file__).resolve().parents[1]

if __name__ == "__main__":
    raise SystemExit(main())
