"""全部实验组的局长记账闭合检查：sum(length) 应等于末行 env_steps。

对每个 completed 运行打印闭合差，并统计 rollout 边界型失配（delta != length 的行），
用于确认历史代码缺陷的影响范围（PPO / A2C 等按 rollout 分批的算法）。
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

RUNS = Path(__file__).resolve().parents[1] / "runs"


def check(man_path: Path) -> dict | None:
    man = json.loads(man_path.read_text(encoding="utf-8"))
    if man.get("status") != "completed":
        return None
    rows = list(csv.DictReader((man_path.parent / "episodes.csv").open(encoding="utf-8")))
    if not rows:
        return None
    total = sum(int(r["length"]) for r in rows)
    last = int(rows[-1]["env_steps"])
    prev, mism = 0, 0
    for r in rows:
        d = int(r["env_steps"]) - prev
        if d != int(r["length"]):
            mism += 1
        prev = int(r["env_steps"])
    return {"env": man["env"], "algo": man["algo"], "seed": man["seed"],
            "rev": man["config"].get("implementation_revision"),
            "rows": len(rows), "sum_len": total, "last": last,
            "gap": last - total, "mismatch_rows": mism,
            "finished": man.get("finished_at", "")}


def main() -> int:
    groups: dict[tuple, list[dict]] = {}
    for m in sorted(RUNS.glob("*/*/seed*/manifest.json")):
        r = check(m)
        if r is None:
            continue
        groups.setdefault((r["env"], r["algo"]), []).append(r)

    print(f"{'env/algo':26s} {'runs':>4s} {'gap(sum of gaps)':>16s} {'mismatch rows':>13s}  verdict")
    problems = []
    for (env, algo), rows in sorted(groups.items()):
        gaps = [r["gap"] for r in rows]
        mism = sum(r["mismatch_rows"] for r in rows)
        has_rev = any(r["rev"] for r in rows)
        bad = [r for r in rows if r["gap"] != 0]
        verdict = "闭合" if not bad else (
            "历史版本记账缺口" if algo in {"ppo", "a2c"} else "未闭合(需查)")
        if bad and algo not in {"ppo", "a2c"}:
            problems.append((env, algo, [r["gap"] for r in bad]))
        print(f"{env + '/' + algo:26s} {len(rows):4d} "
              f"{sum(gaps):16d} {mism:13d}  {verdict}"
              + ("  [policy-audit-v2]" if has_rev else ""))

    # 当前代码应保证闭合：跑过的重训组（policy-audit-v2）必须 gap=0
    for (env, algo), rows in sorted(groups.items()):
        for r in rows:
            if r["rev"] == "policy-audit-v2" and r["gap"] != 0:
                problems.append((env, algo, [f"seed{r['seed']} gap={r['gap']}"]))

    print()
    if problems:
        for p in problems:
            print("[ERR]", p)
    print(f"问题 {len(problems)} 个")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
