"""列出 runs 下每个 (env, algo) 组的运行状态、预算与实现修订。

    python scripts/check_runs.py [--runs-root runs] [--only nav2d]
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

PR = Path(__file__).resolve().parents[1]


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--runs-root", default=str(PR / "runs"))
    p.add_argument("--only", default=None)
    args = p.parse_args()

    root = Path(args.runs_root)
    groups: dict[tuple[str, str], list] = defaultdict(list)
    for m in sorted(root.glob("*/*/seed*/manifest.json")):
        try:
            d = json.loads(m.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            print(f"[bad] {m}: {exc}")
            continue
        c = d.get("config", {})
        groups[(d["env"], d["algo"])].append({
            "seed": int(d["seed"]),
            "status": d.get("status"),
            "budget": c.get("budget"),
            "wall": d.get("wall_seconds"),
            "rev": c.get("implementation_revision"),
            "dir": m.parent.name,
        })

    for (env, algo), rows in sorted(groups.items()):
        if args.only and env != args.only:
            continue
        print(f"== {env}/{algo} ==")
        for r in sorted(rows, key=lambda x: x["seed"]):
            print(f"  seed{r['seed']}: status={r['status']} budget={r['budget']} "
                  f"wall={r['wall']}s rev={r['rev']} dir={r['dir']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
