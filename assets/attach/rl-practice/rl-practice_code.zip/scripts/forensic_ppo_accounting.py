"""PPO 预算记账取证：定位历史 episodes.csv 局长和与预算缺口的来源。

检查：
1. 当前包 source_sha256 与历史 PPO manifest 记录的指纹是否一致（代码版本取证）；
2. 每个种子 episodes.csv 的行数、局长和、末步、以及 env_steps 增量与 length 的失配位置；
3. 失配是否落在 rollout 边界（512 的倍数）附近；
4. 每行 updates 的变化规律（判断历史代码在何处记账）。
"""
from __future__ import annotations

import csv
import glob
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from rlpractice.common.runlog import source_sha256  # noqa: E402

import json  # noqa: E402

ROLLOUT = 512
BUDGET = 100000

cur_hash = source_sha256()
print(f"current package source_sha256: {cur_hash[:16]}...")

for seed in range(5):
    runs = sorted(glob.glob(f"runs/cartpole/ppo/seed{seed}_*/manifest.json"))
    assert runs, f"missing seed{seed}"
    man = json.loads(Path(runs[-1]).read_text(encoding="utf-8"))
    m_hash = man["source_sha256"]
    print(f"\n== seed{seed} {Path(runs[-1]).parent.name} ==")
    print(f"  manifest source_sha256: {m_hash[:16]}...  match_current={m_hash == cur_hash}")

    rows = list(csv.DictReader(open(Path(runs[-1]).parent / "episodes.csv", encoding="utf-8")))
    total = sum(int(r["length"]) for r in rows)
    last_steps = int(rows[-1]["env_steps"])
    print(f"  rows={len(rows)}  sum(length)={total}  last_env_steps={last_steps}  "
          f"gap={last_steps - total}")

    # 逐行核对 env_steps 增量 vs length：失配 = 未被记账的步
    mismatches = []
    prev_steps = 0
    prev_ep = 0
    for r in rows:
        steps, ln, ep = int(r["env_steps"]), int(r["length"]), int(r["episode"])
        delta = steps - prev_steps
        if delta != ln:
            mismatches.append((prev_steps, steps, delta, ln, ep, prev_ep))
        prev_steps, prev_ep = steps, ep

    print(f"  mismatch rows: {len(mismatches)}")
    if mismatches:
        # 失配缺口 = delta - length；位置 = 上一行末步
        gaps = [(pos, d - ln) for pos, _, d, ln, _, _ in mismatches]
        total_gap = sum(g for _, g in gaps)
        print(f"  total gap from mismatches: {total_gap}")
        near512 = sum(1 for pos, _ in gaps if min(abs(pos - k * ROLLOUT)
                       for k in range(BUDGET // ROLLOUT + 2)) <= 2)
        print(f"  gaps within ±2 steps of a 512-multiple: {near512}/{len(gaps)}")
        print(f"  first 5 mismatches (prev_end, cur_end, delta, length, cur_ep, prev_ep): "
              f"{mismatches[:5]}")
        gap_sizes = Counter(g for _, g in gaps)
        print(f"  gap size distribution (top 8): {gap_sizes.most_common(8)}")

    # 协议字段：最后一行的 terminated/truncated；episode 编号是否连续
    eps = [int(r["episode"]) for r in rows]
    noncontig = sum(1 for i in range(1, len(eps)) if eps[i] != eps[i - 1] + 1)
    last = rows[-1]
    print(f"  episode numbering non-contiguous pairs: {noncontig}; "
          f"last row: ep={last['episode']} len={last['length']} "
          f"steps={last['env_steps']} term={last['terminated']} trunc={last['truncated']}")
