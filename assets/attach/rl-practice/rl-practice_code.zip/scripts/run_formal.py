"""正式实验编排：按计划预算跑完整矩阵，支持断点续跑。

    python scripts/run_formal.py [--workers 4] [--only cliff]

规则：
- 每个 (env, algo, seed) 若已存在 completed、budget 一致、且实现修订满足要求的运行 → 跳过；
- 三个需要指定实现修订的算法（coma/maddpg/iddpg）即使有旧 completed 运行也必须重跑；
- 每进程限制线程数避免超订；单次训练超时 60 分钟记为失败并继续；
- 输出与失败原因写 runs/_logs/，进度写 runs/_progress.json。
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PR = Path(__file__).resolve().parents[1]
PYTHON = r"C:\Users\lenovo\anaconda3\envs\pytorch-gpu\python.exe"
RUNS = PR / "runs"
LOGS = RUNS / "_logs"
TIMEOUT = 60 * 60

# (env, algo, budget, seeds)
MATRIX = [
    ("cliff", "qlearning", 100000, 5),
    ("cliff", "sarsa", 100000, 5),
    ("cartpole", "dqn", 100000, 5),
    ("cartpole", "reinforce", 100000, 5),
    ("cartpole", "a2c", 100000, 5),
    ("cartpole", "ppo", 100000, 5),
    ("corridor", "iql", 100000, 5),
    ("corridor", "vdn", 100000, 5),
    ("corridor", "qmix", 100000, 5),
    ("corridor", "coma", 100000, 5),
    ("riddle", "commnet", 50000, 5),
    ("riddle", "commnet_nomsg", 50000, 5),
    ("riddle", "iql", 50000, 5),
    ("nav2d", "maddpg", 62500, 5),
    ("nav2d", "iddpg", 62500, 5),
]


# 需要指定实现修订的算法：修复前的 completed 运行不算完成，必须重跑
REVISION = {
    "coma": "policy-audit-v2",
    "maddpg": "policy-audit-v2",
    "iddpg": "policy-audit-v2",
}


def done_runs() -> dict:
    """(env, algo, seed) -> (budget, implementation_revision)，只认 completed。"""
    out = {}
    for m in RUNS.glob("*/*/seed*/manifest.json"):
        try:
            man = json.loads(m.read_text(encoding="utf-8"))
        except Exception:
            continue
        if man.get("status") != "completed":
            continue
        cfg = man.get("config", {})
        out[(man["env"], man["algo"], int(man["seed"]))] = (
            cfg.get("budget"), cfg.get("implementation_revision"))
    return out


def run_one(env: str, algo: str, seed: int, budget: int) -> dict:
    log_path = LOGS / f"{env}_{algo}_seed{seed}.log"
    env_vars = dict(os.environ)
    env_vars.update(OMP_NUM_THREADS="3", MKL_NUM_THREADS="3", OPENBLAS_NUM_THREADS="3")
    cmd = [PYTHON, "-B", "-m", "rlpractice.train",
           "--algo", algo, "--env", env, "--seed", str(seed),
           "--budget", str(budget), "--runs-root", str(RUNS)]
    t0 = time.time()
    try:
        proc = subprocess.run(cmd, cwd=str(PR), env=env_vars, capture_output=True,
                              text=True, encoding="utf-8", errors="replace",
                              timeout=TIMEOUT)
        ok = proc.returncode == 0
        note = "" if ok else f"exit={proc.returncode}"
        (LOGS / f"{env}_{algo}_seed{seed}.stdout.txt").write_text(proc.stdout, encoding="utf-8")
        (LOGS / f"{env}_{algo}_seed{seed}.stderr.txt").write_text(proc.stderr, encoding="utf-8")
    except subprocess.TimeoutExpired:
        ok, note = False, f"timeout>{TIMEOUT}s"
    return {"env": env, "algo": algo, "seed": seed, "budget": budget,
            "ok": ok, "note": note, "seconds": round(time.time() - t0, 1)}


def needs_run(prev, algo: str, budget: int) -> bool:
    """该 (env, algo, seed) 是否需要（重新）运行。

    prev 为 (budget, implementation_revision) 或 None。
    指定了实现修订的算法，若历史运行的修订不匹配，即使 completed 且预算一致也必须重跑——
    否则修复前的失效结果会被当成已完成而永久跳过。
    """
    if prev is None:
        return True
    prev_budget, prev_rev = prev
    if prev_budget != budget:
        return True
    want_rev = REVISION.get(algo)
    return want_rev is not None and prev_rev != want_rev


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--only", default=None, help="只跑指定 env")
    args = p.parse_args()

    LOGS.mkdir(parents=True, exist_ok=True)
    already = done_runs()
    jobs = []
    for env, algo, budget, n_seeds in MATRIX:
        if args.only and env != args.only:
            continue
        for seed in range(n_seeds):
            prev = already.get((env, algo, seed))
            if not needs_run(prev, algo, budget):
                rev = f", rev={prev[1]}" if REVISION.get(algo) else ""
                print(f"[skip] {env}/{algo}/seed{seed} 已完成(budget={budget}{rev})")
                continue
            jobs.append((env, algo, seed, budget))
    print(f"[plan] 待跑 {len(jobs)} 个运行，并发 {args.workers}")
    if not jobs:
        return 0

    results = []
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(run_one, *j): j for j in jobs}
        for fut in as_completed(futs):
            r = fut.result()
            results.append(r)
            mark = "ok " if r["ok"] else "FAIL"
            print(f"[{mark}] {r['env']}/{r['algo']}/seed{r['seed']} "
                  f"{r['seconds']}s {r['note']}", flush=True)
            progress = {"finished": len(results), "total": len(jobs),
                        "results": results,
                        "updated": time.strftime("%Y-%m-%dT%H:%M:%S")}
            (RUNS / "_progress.json").write_text(
                json.dumps(progress, ensure_ascii=False, indent=2), encoding="utf-8")

    fails = [r for r in results if not r["ok"]]
    print(f"[done] 成功 {len(results)-len(fails)}/{len(results)}")
    for r in fails:
        print(f"  FAIL {r['env']}/{r['algo']}/seed{r['seed']}: {r['note']}")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
