"""重训验收：核对新运行的完整性，并与修复前的历史运行逐参数对比。

    python scripts/verify_retrain.py

检查项：
1. coma/maddpg/iddpg 各有 seed 0–4 的 `policy-audit-v2` 运行，状态 completed、预算一致；
2. 与同种子的历史运行对比 `final.pt` 中 actors[0]/actors[1] 的最大绝对差：
   历史运行的 actors[1] 与初始化逐元素相同（冻结时序缺陷），因此新运行该值必须明显非零；
3. 汇总每种子的最终测试（greedy）回报与验证成功率首末值。
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import torch as th

PR = Path(__file__).resolve().parents[1]
RUNS = PR / "runs"
REV = "policy-audit-v2"
TARGETS = {"corridor": ["coma"], "nav2d": ["maddpg", "iddpg"]}
BUDGET = {"corridor": 100000, "nav2d": 62500}


def load_manifest(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))


def index_runs() -> dict:
    """(env, algo, seed) -> {'new': [dir...], 'old': [dir...]}"""
    out: dict = defaultdict(lambda: {"new": [], "old": []})
    for m in RUNS.glob("*/*/seed*/manifest.json"):
        d = load_manifest(m)
        if d.get("status") != "completed":
            continue
        cfg = d.get("config", {})
        key = (d["env"], d["algo"], int(d["seed"]))
        bucket = "new" if cfg.get("implementation_revision") == REV else "old"
        out[key][bucket].append((d.get("finished_at", ""), m.parent, cfg.get("budget")))
    return out


def latest(entries):
    return max(entries)[1:] if entries else (None, None)


def actor_delta(new_dir: Path, old_dir: Path) -> list[float]:
    a = th.load(new_dir / "checkpoints" / "final.pt", map_location="cpu", weights_only=False)
    b = th.load(old_dir / "checkpoints" / "final.pt", map_location="cpu", weights_only=False)
    deltas = []
    for i in range(len(a["actors"])):
        sd_a, sd_b = a["actors"][i], b["actors"][i]
        worst = 0.0
        for k in sd_a:
            if k in sd_b and sd_a[k].shape == sd_b[k].shape:
                worst = max(worst, float((sd_a[k] - sd_b[k]).abs().max()))
        deltas.append(worst)
    return deltas


def main() -> int:
    idx = index_runs()
    problems: list[str] = []
    for env, algos in TARGETS.items():
        for algo in algos:
            print(f"== {env}/{algo} ==")
            seed_ret: list[float] = []
            seed_succ: list[float] = []
            seed_wall: list[float] = []
            for seed in range(5):
                key = (env, algo, seed)
                new_dir, new_budget = latest(idx[key]["new"])
                old_dir, _ = latest(idx[key]["old"])
                if new_dir is None:
                    problems.append(f"{env}/{algo}/seed{seed}: 缺少 {REV} 运行")
                    print(f"  seed{seed}: 缺少新运行")
                    continue
                if new_budget != BUDGET[env]:
                    problems.append(f"{env}/{algo}/seed{seed}: 预算 {new_budget} != {BUDGET[env]}")
                man = load_manifest(new_dir / "manifest.json")
                if man.get("wall_seconds") is not None:
                    seed_wall.append(float(man["wall_seconds"]))
                line = f"  seed{seed}: {new_dir.name} budget={new_budget}"
                if old_dir is not None:
                    try:
                        d = actor_delta(new_dir, old_dir)
                        line += f" | 与历史运行最大参数差 actor0={d[0]:.4g} actor1={d[1]:.4g}"
                        if d[1] == 0.0:
                            problems.append(
                                f"{env}/{algo}/seed{seed}: actor1 与历史（=初始化）完全相同")
                    except Exception as exc:  # noqa: BLE001
                        line += f" | checkpoint 对比失败: {exc}"
                        problems.append(f"{env}/{algo}/seed{seed}: checkpoint 对比失败 {exc}")
                print(line)

                # 最终测试（greedy）逐局汇总
                ev = new_dir / "evals.csv"
                if ev.exists():
                    import csv
                    rows = [r for r in csv.DictReader(ev.open(encoding="utf-8"))
                            if r.get("policy_mode") == "greedy"
                            and 20000 <= int(r["env_seed"]) < 20100]
                    if rows:
                        ret = sum(float(r["return"]) for r in rows) / len(rows)
                        succ = sum(int(r["success"]) for r in rows) / len(rows)
                        seed_ret.append(ret)
                        seed_succ.append(succ)
                        print(f"          最终测试(greedy {len(rows)} 局): return={ret:.3f} 成功率={succ:.1%}")

            if seed_ret:
                import statistics
                sd = statistics.stdev(seed_ret) if len(seed_ret) > 1 else 0.0
                sds = statistics.stdev(seed_succ) if len(seed_succ) > 1 else 0.0
                print(f"  [组汇总] 每种子测试均值 {statistics.mean(seed_ret):.3f} ± {sd:.3f} (跨种子 SD)")
                print(f"           测试成功率 {100 * statistics.mean(seed_succ):.1f}% ± {100 * sds:.1f}%")
                print(f"           逐种子 return: {[round(x, 3) for x in seed_ret]}")
            if seed_wall:
                import statistics
                print(f"           墙钟 {statistics.mean(seed_wall):.0f}s ± "
                      f"{statistics.stdev(seed_wall) if len(seed_wall) > 1 else 0:.0f}s / 种子")

    print()
    if problems:
        for p in problems:
            print(f"[ERR] {p}")
    print(f"问题 {len(problems)} 个")
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
