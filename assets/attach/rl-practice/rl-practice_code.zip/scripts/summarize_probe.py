"""汇总 runs_probe 的最终测试表现（只读）。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from rlpractice.common.runlog import find_runs, read_run  # noqa: E402
from rlpractice.common.stats import mean  # noqa: E402

runs = find_runs("runs_probe")
for d in sorted(runs, key=lambda p: (p.parent.name, p.name)):
    r = read_run(d)
    m = r["manifest"]
    tests = [x for x in r["evals"]
             if x["env_seed"] >= 20000 and x["policy_mode"] == "greedy"]
    if not tests:
        continue
    rets = [x["return"] for x in tests]
    succ = [x["success"] for x in tests]
    cfg = m["config"]
    keys = ("lr", "eps_decay_steps", "target_sync", "batch_size",
            "rollout", "ent_coef", "epochs", "normalize_adv")
    knobs = {k: cfg.get(k) for k in keys if k in cfg}
    print(f"{m['algo']:8s} seed{m['seed']} budget={cfg['budget']:>6} "
          f"n={len(tests):3d} return={mean(rets):7.1f} "
          f"succ={100 * mean(succ):5.1f}% {knobs}")
