"""三个多智能体教学环境（移植自源项目 02_代码复现/envs.py，语义已修正）。

统一接口：
    env = XxxEnv(seed=0)
    obs, info = env.reset(seed=None)            # obs: (n_agents, obs_dim) float32
    obs, reward, terminated, truncated, info = env.step(actions)

语义约定（对应系列第 11 章的终止/截断区分）：
- terminated = 任务本身结束（成功或明确失败），Bellman 目标**不** bootstrap；
- truncated = 达到回合步数上限（人为时间上限），可 bootstrap；
- info 至少含 `success`；各环境另有专属字段（见各 docstring）。

`fell` 的含义按环境不同，正文引用时必须用对应说法：
- CorridorEnv：超时未送达（失败）；
- RiddleEnv：智能体 1 踩错开关；
- Nav2D：本回合发生过碰撞。
"""
from __future__ import annotations

import numpy as np

__all__ = ["CorridorEnv", "RiddleEnv", "Nav2D", "make_marl_env", "eval_marl"]


class CorridorEnv:
    """两智能体走廊协作（离散、共享奖励）。

    格子 0..8；开关 A=2、门=4、开关 B=6、目标=0。
    两开关被同时踩住 2 步（HOLD_STEPS）门永久打开；门开后任一 agent 到 0 格
    成功得 +10（terminated）；每步 -0.1，撞车 -0.2，10% 打滑；40 步上限=截断。

    观测（5 维）：[自身格子/8, 门开, 自己在开关上, 自身编号, 队友格子/8]
    动作：0=原地, 1=左, 2=右。
    """

    L, SWITCH_A, SWITCH_B, DOOR, GOAL = 9, 2, 6, 4, 0
    HOLD_STEPS = 2
    N_AGENTS = 2
    OBS_DIM = 5
    N_ACTIONS = 3
    MAX_STEPS = 40
    SLIP_P = 0.1

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.default_rng(int(seed))
        self.pos = np.array([self.rng.choice([1, 3]), self.rng.choice([5, 7])], dtype=int)
        self.door_open = False
        self.hold_count = 0
        self.t = 0
        self.collided = False
        return self._obs(), {"door_open": False}

    def step(self, actions):
        actions = np.asarray(actions, dtype=int)
        self.t += 1
        reward = -0.1
        slipped = self.rng.random(self.N_AGENTS) < self.SLIP_P
        actions = np.where(slipped, 0, actions)

        new_pos = self.pos.copy()
        collided = False
        for i in range(self.N_AGENTS):
            a = actions[i]
            if a == 1:
                target = self.pos[i] - 1
            elif a == 2:
                target = self.pos[i] + 1
            else:
                continue
            if target < 0 or target >= self.L:
                continue
            if target == self.DOOR and not self.door_open:
                continue
            if target == new_pos[1 - i]:
                reward -= 0.2
                collided = True
                continue
            new_pos[i] = target
        self.pos = new_pos
        self.collided = self.collided or collided

        on_a = self.SWITCH_A in self.pos
        on_b = self.SWITCH_B in self.pos
        self.hold_count = self.hold_count + 1 if (on_a and on_b) else 0
        if self.hold_count >= self.HOLD_STEPS:
            self.door_open = True

        success = self.door_open and (self.GOAL in self.pos)
        if success:
            reward += 10.0
        truncated = (not success) and (self.t >= self.MAX_STEPS)
        info = {"success": bool(success), "door_open": bool(self.door_open),
                "collided": bool(collided), "timeout": bool(truncated)}
        return self._obs(), reward, bool(success), bool(truncated), info

    def _obs(self):
        obs = []
        for i in range(self.N_AGENTS):
            on_switch = 1.0 if self.pos[i] in (self.SWITCH_A, self.SWITCH_B) else 0.0
            obs.append([self.pos[i] / (self.L - 1), float(self.door_open), on_switch,
                        float(i), self.pos[1 - i] / (self.L - 1)])
        return np.asarray(obs, dtype=np.float32)

    def global_state(self):
        return np.asarray([
            self.pos[0] / (self.L - 1), self.pos[1] / (self.L - 1),
            float(self.door_open),
            1.0 if self.SWITCH_A in self.pos else 0.0,
            1.0 if self.SWITCH_B in self.pos else 0.0,
        ], dtype=np.float32)

    def render_ascii(self):
        row = ["."] * self.L
        row[self.GOAL] = "G"; row[self.SWITCH_A] = "a"; row[self.SWITCH_B] = "b"
        row[self.DOOR] = "=" if self.door_open else "|"
        for i in range(self.N_AGENTS):
            row[self.pos[i]] = str(i)
        return "".join(row)


class RiddleEnv:
    """开关谜题（离散、共享奖励、信息不对称）——通信的最小试验台。

    格子 0..8，第 3 格是墙；正确答案每局随机为 4 或 6，**只有智能体 0 看得到**。
    智能体 1 从 5 出发：踩对 +10（terminated, success），踩错 -5（terminated, fell）。
    每步 -0.1；25 步上限=截断（未作答）。

    观测（3 维）：[自身格子/8, 自身编号, 答案特征]，
    智能体 0 的答案特征 0.0=答案在4 / 1.0=答案在6，智能体 1 恒 0.5（未知）。
    """

    L, WALL, TARGETS = 9, 3, (4, 6)
    N_AGENTS = 2
    OBS_DIM = 3
    N_ACTIONS = 3
    MAX_STEPS = 25

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.default_rng(int(seed))
        self.target = int(self.rng.choice(self.TARGETS))
        self.pos = np.array([1, 5], dtype=int)
        self.t = 0
        return self._obs(), {"target": self.target}

    def step(self, actions):
        actions = np.asarray(actions, dtype=int)
        self.t += 1
        reward = -0.1
        new_pos = self.pos.copy()
        for i in range(self.N_AGENTS):
            a = actions[i]
            target = self.pos[i] - 1 if a == 1 else (self.pos[i] + 1 if a == 2 else self.pos[i])
            if not (0 <= target < self.L) or target == self.WALL or target == new_pos[1 - i]:
                continue
            new_pos[i] = target
        self.pos = new_pos

        success = fell = False
        if self.pos[1] == self.target:
            reward += 10.0
            success = True
        elif self.pos[1] in self.TARGETS:
            reward -= 5.0
            fell = True
        terminated = success or fell
        truncated = (not terminated) and (self.t >= self.MAX_STEPS)
        info = {"success": bool(success), "fell": bool(fell), "target": self.target}
        return self._obs(), reward, bool(terminated), bool(truncated), info

    def _obs(self):
        obs = []
        for i in range(self.N_AGENTS):
            answer = 0.5
            if i == 0:
                answer = 0.0 if self.target == self.TARGETS[0] else 1.0
            obs.append([self.pos[i] / (self.L - 1), float(i), answer])
        return np.asarray(obs, dtype=np.float32)

    def render_ascii(self):
        row = ["."] * self.L
        row[self.WALL] = "#"; row[self.TARGETS[0]] = "L"; row[self.TARGETS[1]] = "R"
        for i in range(self.N_AGENTS):
            row[self.pos[i]] = str(i)
        return "".join(row)


class Nav2D:
    """2D 协同导航（连续动作、共享奖励）：两个质点分工覆盖两块地标。

    场地 [-1,1]^2；动作=连续力（执行前裁剪到 [-1,1]）；
    奖励 = -Σ_地标 min_i 距离，(减) 碰撞 -1，最后 /10。
    观测 8 维：自身位置/速度 + 两个地标相对位置（看不到队友）。
    无真实终止：25 步即 truncated；success=结算时每个地标 0.5 内各有一个不同 agent。
    """

    N_AGENTS, N_LANDMARKS, OBS_DIM, ACT_DIM = 2, 2, 8, 2
    MAX_STEPS, DT = 25, 0.1

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.default_rng(int(seed))
        self.agent_pos = self.rng.uniform(-1.0, 1.0, size=(self.N_AGENTS, 2))
        self.agent_vel = np.zeros((self.N_AGENTS, 2))
        self.landmarks = self.rng.uniform(-1.0, 1.0, size=(self.N_LANDMARKS, 2))
        while np.linalg.norm(self.landmarks[0] - self.landmarks[1]) < 0.4:
            self.landmarks[1] = self.rng.uniform(-1.0, 1.0, size=2)
        self.t = 0
        self.collided = False
        return self._obs(), {}

    def _collides(self):
        return bool(np.linalg.norm(self.agent_pos[0] - self.agent_pos[1]) < 0.2)

    def step(self, actions):
        actions = np.clip(np.asarray(actions, dtype=float), -1.0, 1.0)
        self.t += 1
        self.agent_vel = 0.9 * self.agent_vel + actions * self.DT
        self.agent_pos = np.clip(self.agent_pos + self.agent_vel, -1.0, 1.0)

        reward = 0.0
        for lm in self.landmarks:
            reward -= np.linalg.norm(self.agent_pos - lm, axis=1).min()
        hit = self._collides()
        self.collided = self.collided or hit
        if hit:
            reward -= 1.0
        reward /= 10.0

        truncated = self.t >= self.MAX_STEPS
        success = False
        if truncated:
            d = np.linalg.norm(self.agent_pos[:, None, :] - self.landmarks[None, :, :], axis=2)
            success = bool((d[0, 0] < 0.5 and d[1, 1] < 0.5) or (d[0, 1] < 0.5 and d[1, 0] < 0.5))
        info = {"success": success, "collision": hit, "collided_any": self.collided}
        return self._obs(), float(reward), False, bool(truncated), info

    def _obs(self):
        obs = []
        for i in range(self.N_AGENTS):
            o = list(self.agent_pos[i]) + list(self.agent_vel[i])
            for lm in self.landmarks:
                o += list(lm - self.agent_pos[i])
            obs.append(o)
        return np.asarray(obs, dtype=np.float32)


ENV_REGISTRY = {"corridor": CorridorEnv, "riddle": RiddleEnv, "nav2d": Nav2D}


def make_marl_env(name: str, seed: int = 0):
    if name not in ENV_REGISTRY:
        raise KeyError(f"unknown marl env {name!r}; choose from {sorted(ENV_REGISTRY)}")
    return ENV_REGISTRY[name](seed=seed)


def eval_marl(env_name: str, act_fn, seeds, max_steps: int):
    """统一 MARL 评估：逐局记录 return/length/success/fell/truncated。

    act_fn(joint_obs) -> joint_actions；评估用独立环境实例与显式种子。
    fell 语义按环境不同（见模块 docstring）。
    """
    records = []
    cls = ENV_REGISTRY[env_name]
    for s in seeds:
        env = cls(seed=0)
        obs, _ = env.reset(seed=int(s))
        ret, length = 0.0, 0
        terminated = truncated = False
        info = {}
        fell = False
        while not (terminated or truncated) and length < max_steps:
            actions = act_fn(obs)
            obs, r, terminated, truncated, info = env.step(actions)
            ret += float(r)
            length += 1
            fell = fell or bool(info.get("fell", False)) or bool(
                info.get("timeout", False) and not info.get("success", False))
            if env_name == "nav2d" and info.get("collision"):
                fell = True
        records.append({
            "env_seed": int(s), "return": ret, "length": length,
            "success": bool(info.get("success", False)),
            "fell": bool(fell),
            "truncated": bool(truncated and not terminated),
        })
    return records
