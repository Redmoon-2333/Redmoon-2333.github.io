"""策略梯度类多智能体演示：COMA（走廊）、MADDPG / IDDPG（2D 导航）。

对应系列第 8–9 章。对源实现的三处修正（正文必须写）：

1. **COMA 改为真正的 on-policy**：源版用容量 5000 的持久回放 + ε-uniform
   混合动作，却按“当前策略”的 log-prob 计算 actor loss——没有重要性校正，
   小回放并不能把 off-policy 变成 on-policy。本版：采样期间冻结策略、动作直接
   从当前 categorical 策略采样、critic 与 actor 都只用本迭代全新轨迹、actor
   更新一次后丢弃该批。
2. **MADDPG/IDDPG 各用自己的 target critic**：源版把两个 target critic 的
   输出平均进同一个 y，等于给独立基线也塞了集中式信息。
3. **动作先 clip 再执行与入库**：源版存的是未裁剪动作，而环境执行时才 clip，
   回放里的数据与实际物理不一致。

协议：走廊 COMA 与价值类同预算（100k 联合步）；导航 MADDPG/IDDPG 62500 联合步。
最终测试 100 局（20000+），COMA 同时报 greedy 与 stochastic 两种模式。
"""
from __future__ import annotations

from itertools import product

import numpy as np
import torch as th

from rlpractice.common.registry import register
from rlpractice.common.evaluate import summarize
from rlpractice.algos.marl.common import mlp, soft_update, freeze
from rlpractice.algos.marl.envs import eval_marl, make_marl_env
from rlpractice.algos.marl.value import DEFAULTS as VALUE_DEFAULTS, eps_at

DEFAULTS = dict(VALUE_DEFAULTS)
DEFAULTS.update({
    "implementation_revision": "policy-audit-v2",
    "actor_lr": 1e-3,
    "critic_lr": 1e-3,
    "batch_episodes": 16,     # COMA 每迭代的新轨迹局数
    "critic_epochs": 4,
    "entropy_coef": 0.01,
    "tau": 0.01,              # MADDPG 软更新
    "noise_std": 0.1,         # MADDPG 训练探索噪声
    "warmup": 1000,
})


# ============================================================================ COMA
def _onehot_joint(actions, n_actions):
    a = np.asarray(actions, dtype=np.int64).reshape(-1)
    out = np.zeros(a.size * n_actions, dtype=np.float32)
    for i, v in enumerate(a):
        out[i * n_actions + v] = 1.0
    return out


class COMACritic(th.nn.Module):
    """Q(s, a_joint)：全局状态 + 联合动作 onehot → 标量。"""

    def __init__(self, state_dim, joint_action_dim, hidden=64):
        super().__init__()
        self.net = mlp([state_dim + joint_action_dim, hidden, hidden, 1])

    def forward(self, state, onehot):
        return self.net(th.cat([state, onehot], dim=-1)).squeeze(-1)


def counterfactual_baseline(pi, q_alt):
    """Σ_{a'} π(a'|o) Q(s,[a_-i,a'])：可手算核对的反事实基线。"""
    return (pi * q_alt).sum(dim=-1)


def coma_advantage(q_taken, q_alt, pi):
    """A_i = Q(s,a) − baseline；返回 detach 的优势，梯度不回流到 critic。"""
    return (q_taken - counterfactual_baseline(pi, q_alt)).detach()


def sample_categorical(logits, rng):
    """使用显式 NumPy RNG，不消耗训练用的 Torch 全局随机流。"""
    return np.asarray([
        rng.choice(len(l), p=l.detach().softmax(-1).cpu().numpy())
        for l in logits], dtype=np.int64)


def joint_policy_value(critic, states, probabilities):
    """精确枚举小离散联合动作的 E_pi[Q]，不是 Q(E_pi[onehot])。

    probabilities: (B, n_agents, n_actions)。仅用于教学小动作空间。
    """
    batch, n_agents, n_actions = probabilities.shape
    value = states.new_zeros(batch)
    for actions in product(range(n_actions), repeat=n_agents):
        onehot = states.new_tensor(_onehot_joint(actions, n_actions)).expand(batch, -1)
        weight = probabilities.new_ones(batch)
        for i, action in enumerate(actions):
            weight = weight * probabilities[:, i, action]
        value = value + weight * critic(states, onehot)
    return value


def run_coma(cfg: dict, log) -> dict:
    env_name = str(cfg["env"])
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma = float(cfg["gamma"])
    hidden = int(cfg["hidden"])
    rng = np.random.default_rng(seed)
    th.manual_seed(seed)

    env = make_marl_env(env_name, seed=seed)
    obs, _ = env.reset(seed=seed)
    n_agents, obs_dim, n_actions = env.N_AGENTS, env.OBS_DIM, env.N_ACTIONS
    state_dim = len(env.global_state())
    max_steps = env.MAX_STEPS
    joint_a_dim = n_agents * n_actions

    actors = [mlp([obs_dim, hidden, hidden, n_actions]) for _ in range(n_agents)]
    critic = COMACritic(state_dim, joint_a_dim, hidden)
    tgt_critic = COMACritic(state_dim, joint_a_dim, hidden)
    tgt_critic.load_state_dict(critic.state_dict())
    actor_opt = th.optim.Adam([p for a in actors for p in a.parameters()],
                              lr=float(cfg["actor_lr"]))
    critic_opt = th.optim.Adam(critic.parameters(), lr=float(cfg["critic_lr"]))

    def policy_dist(o):
        """o: (n, obs_dim) numpy → 每个 agent 的 logits 列表。"""
        out = []
        for i, net in enumerate(actors):
            with th.no_grad():
                out.append(net(th.as_tensor(o[i][None], dtype=th.float32))[0])
        return out

    def greedy(o):
        return np.asarray([int(l.argmax()) for l in policy_dist(o)], dtype=np.int64)

    def sample(o, sample_rng):
        return sample_categorical(policy_dist(o), sample_rng)

    def evaluate(seeds, mode):
        if mode == "greedy":
            fn = greedy
        else:
            records = []
            for eval_seed in seeds:
                eval_rng = np.random.default_rng(np.random.SeedSequence([98765, int(eval_seed)]))
                fn = lambda o, r=eval_rng: sample(o, r)
                records.extend(eval_marl(env_name, fn, [eval_seed], max_steps))
            return records
        return eval_marl(env_name, fn, seeds, max_steps)

    def train_critic(transitions):
        st = th.as_tensor(np.stack([t["s"] for t in transitions]))
        oh = th.as_tensor(np.stack([_onehot_joint(t["a"], n_actions) for t in transitions]))
        rew = th.as_tensor(np.array([t["r"] for t in transitions], dtype=np.float32))
        nst = th.as_tensor(np.stack([t["ns"] for t in transitions]))
        don = th.as_tensor(np.array([t["done"] for t in transitions], dtype=np.float32))
        # E_pi[Q(s', a')]：枚举 3^2 个离散联合动作，不能把概率向量当动作。
        with th.no_grad():
            next_obs = th.as_tensor(np.stack([t["no"] for t in transitions]))
            probs = th.stack([actor(next_obs[:, i]).softmax(-1)
                              for i, actor in enumerate(actors)], dim=1)
            next_value = joint_policy_value(tgt_critic, nst, probs)
            y = rew + gamma * (1.0 - don) * next_value
        losses = []
        for _ in range(int(cfg["critic_epochs"])):
            pred = critic(st, oh)
            loss = th.nn.functional.smooth_l1_loss(pred, y)
            critic_opt.zero_grad()
            loss.backward()
            critic_opt.step()
            losses.append(float(loss.detach()))
        return losses

    def train_actor(transitions):
        """advantage = Q(s,a) − Σ_a' π_i(a'|o_i) Q(s,[a_-i,a'])，advantage detach。"""
        st = th.as_tensor(np.stack([t["s"] for t in transitions]))
        oh_all = th.as_tensor(np.stack(
            [_onehot_joint(t["a"], n_actions) for t in transitions]))
        idx_all = th.as_tensor(np.stack([t["a"] for t in transitions]))
        total_loss = 0.0
        obs_stack = th.as_tensor(np.stack(
            [np.stack([t["o_i"][i] for t in transitions]) for i in range(n_agents)]))
        for i, actor in enumerate(actors):
            # 必须保留梯度：logits 要连回第 i 个 actor（advantage 与 baseline 已 detach）
            logits = actor(obs_stack[i])
            logp = th.distributions.Categorical(logits=logits).log_prob(idx_all[:, i])

            with th.no_grad():
                q_taken = critic(st, oh_all)
                # 枚举本 agent 的每个动作，替换 onehot 后重算 Q
                q_alt = []
                for a_prime in range(n_actions):
                    oh2 = oh_all.clone()
                    oh2[:, i * n_actions:(i + 1) * n_actions] = 0.0
                    oh2[:, i * n_actions + a_prime] = 1.0
                    q_alt.append(critic(st, oh2))
                q_alt = th.stack(q_alt, dim=1)                 # (B, A)
                pi = th.softmax(logits, dim=-1)
            adv = coma_advantage(q_taken, q_alt, pi)           # detach
            ent = th.distributions.Categorical(logits=logits).entropy()
            loss = -(logp * adv).mean() - float(cfg["entropy_coef"]) * ent.mean()
            actor_opt.zero_grad()
            for other in actors:
                freeze(other, True)
            freeze(actor, False)
            loss.backward()
            actor_opt.step()
            for other in actors:
                freeze(other, False)
            total_loss += float(loss.detach())
        return total_loss

    # —— 主循环：按迭代组织（收集 → critic → actor → 丢弃）——
    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)
    state = env.global_state()
    ep_ret, ep_len = 0.0, 0

    while env_steps < budget:
        # 为 transitions 记录 per-agent obs（actor 输入）
        batch = []
        episodes_in_batch = 0
        while episodes_in_batch < int(cfg["batch_episodes"]) and env_steps < budget:
            a = sample(obs, rng)
            # 记录每个 agent 的观测
            obs_snapshot = obs.copy()
            nobs, r, term, trunc, info = env.step(a)
            env_steps += 1
            ep_ret += r
            ep_len += 1
            batch.append({
                "s": state.copy(), "a": a.copy(), "r": float(r),
                "ns": env.global_state().copy(), "no": nobs.copy(),
                "done": float(term), "o_i": obs_snapshot,
            })
            state = env.global_state()
            obs = nobs

            budget_hit = env_steps >= budget and not (term or trunc)
            if term or trunc or budget_hit:
                episode += 1
                episodes_in_batch += 1
                log.episode(episode, ep_ret, ep_len, env_steps, updates,
                            term, trunc or budget_hit)
                obs, _ = env.reset()
                state = env.global_state()
                ep_ret, ep_len = 0.0, 0
                if budget_hit:
                    break

        if batch:
            train_critic(batch)
            train_actor(batch)
            updates += 1
            soft_update(tgt_critic, critic, float(cfg["tau"]))
            del batch

        if env_steps >= next_eval:
            recs = evaluate(range(int(cfg["val_seed_base"]),
                                  int(cfg["val_seed_base"]) + int(cfg["eval_episodes"])),
                            "greedy")
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

    tests = {}
    for mode in ("greedy", "stochastic"):
        recs = evaluate(range(int(cfg["test_seed_base"]),
                              int(cfg["test_seed_base"]) + int(cfg["test_episodes"])),
                        mode)
        log.evaluate(step=env_steps, policy_mode=mode, records=recs)
        tests[mode] = summarize(recs)

    th.save({"actors": [a.state_dict() for a in actors],
             "critic": critic.state_dict(), "config": dict(cfg)},
            log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")
    return {"env_steps": env_steps, "episodes": episode, "updates": updates,
            "test": tests}


# ============================================================ MADDPG / IDDPG
def run_maddpg_like(mode: str, cfg: dict, log) -> dict:
    assert mode in ("ctde", "indep")
    env_name = str(cfg["env"])
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma = float(cfg["gamma"])
    hidden = int(cfg["hidden"])
    tau = float(cfg["tau"])
    rng = np.random.default_rng(seed)
    th.manual_seed(seed)

    env = make_marl_env(env_name, seed=seed)
    obs, _ = env.reset(seed=seed)
    n_agents = env.N_AGENTS
    obs_dim = env.OBS_DIM
    act_dim = env.ACT_DIM
    max_steps = env.MAX_STEPS

    actors = [mlp([obs_dim, hidden, hidden, act_dim], out_act=th.nn.Tanh)
              for _ in range(n_agents)]
    tgt_actors = [mlp([obs_dim, hidden, hidden, act_dim], out_act=th.nn.Tanh)
                  for _ in range(n_agents)]
    for t, s in zip(tgt_actors, actors):
        t.load_state_dict(s.state_dict())

    def critic_in(o_all, a_all):
        if mode == "ctde":
            return th.cat([o_all.flatten(1), a_all.flatten(1)], dim=-1)
        return None

    if mode == "ctde":
        c_in_dim = n_agents * obs_dim + n_agents * act_dim
        critics = [mlp([c_in_dim, hidden, hidden, 1]) for _ in range(n_agents)]
        tgt_critics = [mlp([c_in_dim, hidden, hidden, 1]) for _ in range(n_agents)]
    else:
        c_in_dim = obs_dim + act_dim
        critics = [mlp([c_in_dim, hidden, hidden, 1]) for _ in range(n_agents)]
        tgt_critics = [mlp([c_in_dim, hidden, hidden, 1]) for _ in range(n_agents)]
    for t, s in zip(tgt_critics, critics):
        t.load_state_dict(s.state_dict())

    actor_params = [p for a in actors for p in a.parameters()]
    critic_params = [p for c in critics for p in c.parameters()]
    actor_opt = th.optim.Adam(actor_params, lr=float(cfg["actor_lr"]))
    critic_opt = th.optim.Adam(critic_params, lr=float(cfg["critic_lr"]))

    cap = int(cfg["replay_capacity"])
    buf = {"o": np.zeros((cap, n_agents, obs_dim), dtype=np.float32),
           "a": np.zeros((cap, n_agents, act_dim), dtype=np.float32),
           "r": np.zeros(cap, dtype=np.float32),
           "no": np.zeros((cap, n_agents, obs_dim), dtype=np.float32),
           "d": np.zeros(cap, dtype=np.float32), "n": 0, "i": 0}

    def push(o, a, r, no, d):
        buf["o"][buf["i"]] = o; buf["a"][buf["i"]] = a
        buf["r"][buf["i"]] = r; buf["no"][buf["i"]] = no; buf["d"][buf["i"]] = d
        buf["i"] = (buf["i"] + 1) % cap
        buf["n"] = min(buf["n"] + 1, cap)

    def sample_batch(batch):
        idx = rng.integers(0, buf["n"], size=batch)
        return {k: buf[k][idx] for k in ("o", "a", "r", "no", "d")}

    def actor_forward(nets, o):
        return th.stack([net(o[:, i]) for i, net in enumerate(nets)], dim=1)

    def greedy(o):
        with th.no_grad():
            t_o = th.as_tensor(o[None], dtype=th.float32)
            return actor_forward(actors, t_o)[0].numpy()

    def act(o, noise_std):
        with th.no_grad():
            t_o = th.as_tensor(o[None], dtype=th.float32)
            a = actor_forward(actors, t_o)[0].numpy()
        a = a + noise_std * rng.standard_normal(a.shape)
        return np.clip(a, -1.0, 1.0)          # 执行前 clip（修正：源版入库未裁剪）

    def critic_inputs(o_all, a_all, i):
        if mode == "ctde":
            return th.cat([o_all.flatten(1), a_all.flatten(1)], dim=-1)
        return th.cat([o_all[:, i], a_all[:, i]], dim=-1)

    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)
    ep_ret, ep_len = 0.0, 0
    noise = float(cfg["noise_std"])

    while env_steps < budget:
        a = act(obs, noise)
        nobs, r, term, trunc, info = env.step(a)
        env_steps += 1
        ep_ret += r
        ep_len += 1
        push(obs, a, float(r), nobs, float(term))   # terminated 恒 False（连续任务）
        obs = nobs

        if buf["n"] >= int(cfg["warmup"]):
            bd = sample_batch(int(cfg["batch_size"]))
            o_t = th.as_tensor(bd["o"])
            a_t = th.as_tensor(bd["a"])
            r_t = th.as_tensor(bd["r"])
            no_t = th.as_tensor(bd["no"])
            d_t = th.as_tensor(bd["d"])

            with th.no_grad():
                next_a_t = actor_forward(tgt_actors, no_t)     # 目标策略的下一动作
                y = []
                for i in range(n_agents):
                    qi_next = tgt_critics[i](critic_inputs(no_t, next_a_t, i)).squeeze(-1)
                    y.append(r_t + gamma * (1.0 - d_t) * qi_next)
                y = th.stack(y, dim=1)                          # (B, n) 各自目标

            critic_loss = 0.0
            for i in range(n_agents):
                pred = critics[i](critic_inputs(o_t, a_t, i)).squeeze(-1)
                assert pred.shape == y[:, i].shape == r_t.shape
                critic_loss = critic_loss + th.nn.functional.smooth_l1_loss(pred, y[:, i])
            critic_opt.zero_grad()
            critic_loss.backward()
            critic_opt.step()

            # actor 更新：冻结 critic，只推各自 actor
            for c in critics:
                freeze(c, True)
            actor_loss_val = 0.0
            for i in range(n_agents):
                # 必须在 forward 建图前恢复当前 actor 的梯度。
                for j, a_net in enumerate(actors):
                    freeze(a_net, j != i)
                actor_opt.zero_grad(set_to_none=True)
                new_a = actor_forward(actors, o_t)
                qi = critics[i](critic_inputs(o_t, new_a, i))
                loss = -qi.mean()
                loss.backward()
                actor_opt.step()
                actor_loss_val += float(loss.detach())
            for c in critics:
                freeze(c, False)
            for a_net in actors:
                freeze(a_net, False)

            updates += 1
            for t, s in zip(tgt_actors, actors):
                soft_update(t, s, tau)
            for t, s in zip(tgt_critics, critics):
                soft_update(t, s, tau)

        budget_hit = env_steps >= budget and not (term or trunc)
        if term or trunc or budget_hit:
            episode += 1
            log.episode(episode, ep_ret, ep_len, env_steps, updates,
                        term, trunc or budget_hit)
            obs, _ = env.reset()
            ep_ret, ep_len = 0.0, 0

        if env_steps >= next_eval:
            recs = eval_marl(env_name, greedy,
                             range(int(cfg["val_seed_base"]),
                                   int(cfg["val_seed_base"]) + int(cfg["eval_episodes"])),
                             max_steps)
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

    test_records = eval_marl(env_name, greedy,
                             range(int(cfg["test_seed_base"]),
                                   int(cfg["test_seed_base"]) + int(cfg["test_episodes"])),
                             max_steps)
    log.evaluate(step=env_steps, policy_mode="greedy", records=test_records)
    th.save({"actors": [a.state_dict() for a in actors],
             "critics": [c.state_dict() for c in critics], "config": dict(cfg)},
            log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")
    return {"env_steps": env_steps, "episodes": episode, "updates": updates,
            "test": summarize(test_records)}


@register("coma")
def run_coma_registered(cfg: dict, log) -> dict:
    return run_coma(cfg, log)


@register("maddpg")
def run_maddpg(cfg: dict, log) -> dict:
    return run_maddpg_like("ctde", cfg, log)


@register("iddpg")
def run_iddpg(cfg: dict, log) -> dict:
    return run_maddpg_like("indep", cfg, log)
