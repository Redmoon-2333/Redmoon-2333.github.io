"""走廊/谜题上的价值类方法：IQL（神经独立学习）、VDN、QMIX。

对应系列第 6–7 章。三个方法共用同一套个体 Q 网络与联合回放，差别只在
**团队价值怎么组合**，这正是“同预算比较”的前提：

- IQL：各学各的，团队奖励照单全收（独立 bootstrap，互相把对方当环境）；
- VDN：Q_tot = Σ_i Q_i（加和分解）；
- QMIX：Q_tot = mixer(Q_i; s)，超网络生成权重并保证对每个 Q_i 单调不减。

对源实现的修正（docstring 记档，正文要写）：
- 源 QMIX 的最终偏置经过 ReLU，配合非负权重与 ReLU 隐层，Q_tot 被迫 ≥0，
  而本环境团队奖励含每步 -0.1 与失败负回报 → 无法表示负价值。
  本版：隐层 ELU、混合权重 |·|、最终偏置不加激活（可为负），并用测试保证
  ①对每个 Q_i 单调；②能输出负值。
- bootstrap 约定：terminated 不外推，truncated（回合上限）照常外推。

评估：验证 20 局（10000+）每 eval_every 联合步一次；最终测试 100 局（20000+）
贪心策略，逐局原始记录落盘。
"""
from __future__ import annotations

import numpy as np
import torch as th

from rlpractice.common.registry import register
from rlpractice.algos.marl.common import epsilon_greedy, mlp, soft_update
from rlpractice.algos.marl.envs import eval_marl, make_marl_env

DEFAULTS = {
    "gamma": 0.95,
    "eps_start": 0.5,
    "eps_end": 0.05,
    "eps_frac": 0.6,          # ε 在前 60% 预算内线性衰减
    "hidden": 64,
    "lr": 1e-3,
    "replay_capacity": 20000,
    "batch_size": 64,
    "warmup": 500,
    "target_sync": 500,
    "eval_every": None,       # None → budget // 10
    "eval_episodes": 20,
    "test_episodes": 100,
    "val_seed_base": 10000,
    "test_seed_base": 20000,
}


class JointReplay:
    """整条联合转移一起存：IQL/VDN/QMIX 共用，保证三者消费同一批数据接口。"""

    def __init__(self, capacity, n_agents, obs_dim, state_dim):
        self.cap = capacity
        self.n = 0
        self.i = 0
        self.obs = np.zeros((capacity, n_agents, obs_dim), dtype=np.float32)
        self.act = np.zeros((capacity, n_agents), dtype=np.int64)
        self.rew = np.zeros(capacity, dtype=np.float32)
        self.nobs = np.zeros((capacity, n_agents, obs_dim), dtype=np.float32)
        self.done = np.zeros(capacity, dtype=np.float32)   # 1 = terminated
        self.state = np.zeros((capacity, state_dim), dtype=np.float32)   # 当前全局状态
        self.nstate = np.zeros((capacity, state_dim), dtype=np.float32)  # 下一全局状态

    def push(self, obs, act, rew, nobs, done, state, nstate):
        self.obs[self.i] = obs
        self.act[self.i] = act
        self.rew[self.i] = rew
        self.nobs[self.i] = nobs
        self.done[self.i] = float(done)
        self.state[self.i] = state
        self.nstate[self.i] = nstate
        self.i = (self.i + 1) % self.cap
        self.n = min(self.n + 1, self.cap)

    def sample(self, batch, rng):
        idx = rng.integers(0, self.n, size=batch)
        return {k: getattr(self, k)[idx] for k in
                ("obs", "act", "rew", "nobs", "done", "state", "nstate")}


def make_q_nets(n_agents, obs_dim, n_actions, hidden):
    return th.nn.ModuleList([mlp([obs_dim, hidden, hidden, n_actions]) for _ in range(n_agents)])


class QMixer(th.nn.Module):
    """单调混合网络：权重取绝对值，隐层 ELU，最终偏置自由（可负）。"""

    def __init__(self, n_agents, state_dim, hidden=32):
        super().__init__()
        self.n_agents = n_agents
        self.hidden = hidden
        self.hyper_w1 = th.nn.Linear(state_dim, hidden * n_agents)
        self.hyper_b1 = th.nn.Linear(state_dim, hidden)
        self.hyper_w2 = th.nn.Linear(state_dim, hidden)
        self.hyper_b2 = th.nn.Linear(state_dim, 1)   # 无激活：允许负团队价值

    def forward(self, agent_qs, states):
        w1 = th.abs(self.hyper_w1(states)).view(-1, self.n_agents, self.hidden)
        b1 = self.hyper_b1(states).unsqueeze(1)
        w2 = th.abs(self.hyper_w2(states)).view(-1, self.hidden, 1)
        b2 = self.hyper_b2(states)
        hidden = th.nn.functional.elu(th.bmm(agent_qs.unsqueeze(1), w1) + b1)
        return (th.bmm(hidden, w2).squeeze(-1) + b2).squeeze(-1)


def eps_at(cfg, step, budget):
    frac = min(1.0, step / max(1.0, float(cfg["eps_frac"]) * budget))
    return float(cfg["eps_start"]) + frac * (float(cfg["eps_end"]) - float(cfg["eps_start"]))


def td_target(rew, don, gamma, next_values, mode="element"):
    """统一的 TD 目标，便于单元测试核对终止语义。

    - `don=1`（terminated）→ 目标只剩 r，不外推；
    - `don=0`（含 truncated 的人为上限）→ 照常 γ·next；
    - mode：
      * "joint"：r + γ(1-d)·Σ_i next_i（先对智能体维求和，r 只加一次；VDN）；
      * "per_agent"：把 r/d 广播到每个智能体，逐 agent 算（IQL）；
      * "element"：next 与 r 同形状，直接逐元素（QMIX 的 Q_tot、单智能体）。
    """
    if mode == "joint":
        return rew + gamma * (1.0 - don) * next_values.sum(-1)
    if mode == "per_agent":
        return rew.unsqueeze(-1) + gamma * (1.0 - don).unsqueeze(-1) * next_values
    if mode == "element":
        return rew + gamma * (1.0 - don) * next_values
    raise ValueError(f"unknown mode {mode!r}")


def _run(algo: str, cfg: dict, log) -> dict:
    env_name = str(cfg["env"])
    if algo in ("vdn", "qmix") and env_name != "corridor":
        raise ValueError(f"{algo} 目前只配置了 corridor 环境（qmix 需要全局状态）")
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma = float(cfg["gamma"])
    hidden = int(cfg["hidden"])
    batch = int(cfg["batch_size"])
    rng = np.random.default_rng(seed)
    th.manual_seed(seed)

    env = make_marl_env(env_name, seed=seed)
    obs, _ = env.reset(seed=seed)
    n_agents = env.N_AGENTS
    obs_dim = env.OBS_DIM
    n_actions = env.N_ACTIONS
    max_steps = env.MAX_STEPS
    state_dim = len(env.global_state()) if hasattr(env, "global_state") else 0

    q_nets = make_q_nets(n_agents, obs_dim, n_actions, hidden)
    tgt_nets = make_q_nets(n_agents, obs_dim, n_actions, hidden)
    for t, s in zip(tgt_nets, q_nets):
        t.load_state_dict(s.state_dict())
    params = [p for net in q_nets for p in net.parameters()]
    if algo == "qmix":
        mixer = QMixer(n_agents, state_dim)
        tgt_mixer = QMixer(n_agents, state_dim)
        tgt_mixer.load_state_dict(mixer.state_dict())
        params += list(mixer.parameters())
    else:
        mixer = tgt_mixer = None
    opt = th.optim.Adam(params, lr=float(cfg["lr"]))
    if state_dim == 0:   # 非走廊环境没有 global_state：占位零向量（仅 qmix 会用到，已禁用）
        state_dim = 1
    replay = JointReplay(int(cfg["replay_capacity"]), n_agents, obs_dim, state_dim)

    def agent_qs(nets, o):
        return th.stack([net(o[:, i]) for i, net in enumerate(nets)], dim=1)  # (B, n, A)

    def greedy_actions(o):
        with th.no_grad():
            return np.stack([
                int(net(th.as_tensor(o[i], dtype=th.float32)).argmax().item())
                for i, net in enumerate(q_nets)])

    def act(obs_np, eps):
        acts = []
        for i, net in enumerate(q_nets):
            with th.no_grad():
                q = net(th.as_tensor(obs_np[i])).numpy()
            acts.append(epsilon_greedy(q, eps, rng))
        return np.asarray(acts, dtype=np.int64)

    def evaluate(mode_seeds):
        def fn(o):
            return greedy_actions(o)
        return eval_marl(env_name, fn, mode_seeds, max_steps)

    def zero_state(obs_np):
        if hasattr(env, "global_state"):
            return env.global_state()
        return np.zeros(state_dim, dtype=np.float32)

    env_steps = episode = updates = 0
    next_eval = eval_every
    ep_ret, ep_len = 0.0, 0
    terminated = truncated = False

    while env_steps < budget:
        a = act(obs, eps_at(cfg, env_steps, budget))
        nobs, r, terminated, truncated, info = env.step(a)
        env_steps += 1
        ep_ret += r
        ep_len += 1
        state = zero_state(obs)
        nstate = zero_state(nobs)
        replay.push(obs, a, r, nobs, terminated, state, nstate)
        obs = nobs

        if replay.n >= int(cfg["warmup"]):
            batch_data = replay.sample(batch, rng)
            ob = th.as_tensor(batch_data["obs"])
            ac = th.as_tensor(batch_data["act"])
            rew = th.as_tensor(batch_data["rew"])
            nob = th.as_tensor(batch_data["nobs"])
            don = th.as_tensor(batch_data["done"])
            sts = th.as_tensor(batch_data["state"])
            nst = th.as_tensor(batch_data["nstate"])

            qs = agent_qs(q_nets, ob)                        # (B, n, A)
            q_taken = qs.gather(2, ac.unsqueeze(-1)).squeeze(-1)  # (B, n)

            with th.no_grad():
                qns = agent_qs(tgt_nets, nob)                # (B, n, A)
                q_next = qns.max(2).values                   # 各自独立 max
                if algo == "qmix":
                    q_tot_next = tgt_mixer(q_next, nst)
                    target = td_target(rew, don, gamma, q_tot_next, mode="element")
                else:
                    target = td_target(rew, don, gamma, q_next, mode="joint")

            if algo in ("iql", "vdn"):
                # iql 与 vdn 的差别在“谁的梯度到谁”：iql 对每个 agent 分别算 TD，
                # vdn 让梯度流过联合和（这里两者目标数值一致，损失形式不同）。
                if algo == "vdn":
                    pred = q_taken.sum(1)
                    loss = th.nn.functional.smooth_l1_loss(pred, target)
                else:
                    per_target = td_target(rew, don, gamma, q_next, mode="per_agent")
                    loss = th.nn.functional.smooth_l1_loss(q_taken, per_target)
            else:
                pred = mixer(q_taken, sts)
                loss = th.nn.functional.smooth_l1_loss(pred, target)

            opt.zero_grad()
            loss.backward()
            th.nn.utils.clip_grad_norm_(params, 10.0)
            opt.step()
            updates += 1
            if env_steps % int(cfg["target_sync"]) == 0:
                for t, s in zip(tgt_nets, q_nets):
                    soft_update(t, s, 1.0)
                if mixer is not None:
                    soft_update(tgt_mixer, mixer, 1.0)

        budget_hit = env_steps >= budget and not (terminated or truncated)
        if terminated or truncated or budget_hit:
            episode += 1
            log.episode(episode, ep_ret, ep_len, env_steps, updates,
                        terminated, truncated or budget_hit)
            obs, _ = env.reset()
            ep_ret, ep_len = 0.0, 0
            terminated = truncated = False

        if env_steps >= next_eval:
            recs = evaluate(range(int(cfg["val_seed_base"]),
                                  int(cfg["val_seed_base"]) + int(cfg["eval_episodes"])))
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

    test_records = evaluate(range(int(cfg["test_seed_base"]),
                                  int(cfg["test_seed_base"]) + int(cfg["test_episodes"])))
    log.evaluate(step=env_steps, policy_mode="greedy", records=test_records)

    ckpt = {"q_nets": [n.state_dict() for n in q_nets], "config": dict(cfg)}
    if mixer is not None:
        ckpt["mixer"] = mixer.state_dict()
    th.save(ckpt, log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")

    from rlpractice.common.evaluate import summarize
    return {
        "env_steps": env_steps, "episodes": episode, "updates": updates,
        "test": summarize(test_records),
    }


@register("iql")
def run_iql(cfg: dict, log) -> dict:
    return _run("iql", cfg, log)


@register("vdn")
def run_vdn(cfg: dict, log) -> dict:
    return _run("vdn", cfg, log)


@register("qmix")
def run_qmix(cfg: dict, log) -> dict:
    return _run("qmix", cfg, log)
