"""MARL 各算法共享的小工具：网络、回放、软更新、探索。

刻意保持极简——教学演示要让每一行都能被读懂和改动。
"""
from __future__ import annotations

import numpy as np
import torch as th


def mlp(sizes, act_cls=th.nn.ReLU, out_act=None):
    """多层感知机：sizes=[in, h..., out]。"""
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(th.nn.Linear(sizes[i], sizes[i + 1]))
        if i < len(sizes) - 2:
            layers.append(act_cls())
    if out_act is not None:
        layers.append(out_act())
    return th.nn.Sequential(*layers)


def soft_update(target: th.nn.Module, source: th.nn.Module, tau: float):
    with th.no_grad():
        for tp, sp in zip(target.parameters(), source.parameters()):
            tp.mul_(1.0 - tau).add_(sp, alpha=tau)


def freeze(module: th.nn.Module, flag: bool = True):
    for p in module.parameters():
        p.requires_grad_(not flag)


class Replay:
    """固定容量转移回放（存 numpy，采样转 tensor）。"""

    def __init__(self, capacity: int):
        self.capacity = int(capacity)
        self.buf = []
        self.i = 0

    def push(self, *items):
        if len(self.buf) < self.capacity:
            self.buf.append(items)
        else:
            self.buf[self.i] = items
        self.i = (self.i + 1) % self.capacity

    def __len__(self):
        return len(self.buf)

    def sample(self, batch: int, rng: np.random.Generator):
        idx = rng.integers(0, len(self.buf), size=min(batch, len(self.buf)))
        items = [self.buf[j] for j in idx]
        cols = list(zip(*items))
        return tuple(np.asarray(c) for c in cols)


def epsilon_greedy(q_values: np.ndarray, eps: float, rng: np.random.Generator) -> int:
    """每个 agent 的 Q 行上做 ε-greedy；平局由 argmax 固定（动作 0 优先）。"""
    if rng.random() < eps:
        return int(rng.integers(q_values.shape[-1]))
    return int(np.argmax(q_values))


def one_hot(a, n):
    v = np.zeros(n, dtype=np.float32)
    v[int(a)] = 1.0
    return v
