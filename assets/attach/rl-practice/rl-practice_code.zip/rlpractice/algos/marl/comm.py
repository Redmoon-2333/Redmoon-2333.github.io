"""通信机制演示：CommNet 式同步通信 + VDN 式联合值学习（开关谜题）。

对应系列第 10 章。定位是**教学机制演示**，不是 CommNet 原论文复现：
- 同步通信：第 k 轮每个 agent 的聚合消息来自队友**上一轮**的广播
  （源实现用的是静态缓存，没有真正的轮次，本版已修正）；
- 值学习用联合 summed-Q TD（VDN 式），因此准确名称是
  “CommNet 式通信 + VDN 值学习”；
- `commnet_nomsg` 消融：**网络深度与参数量完全一致**，唯一差别是把消息
  置零——源实现把 comm_rounds=0 连深度一起砍掉，通信与深度的贡献混在一起，
  无法归因（正文要说明这一修正）。

谜题环境里答案只有 agent 0 看得到：无通信方法的上限是 50%，
通信必须把信息传过去才可能突破——这就是本实验要观察的量。
"""
from __future__ import annotations

import numpy as np
import torch as th

from rlpractice.common.registry import register
from rlpractice.algos.marl.common import epsilon_greedy, soft_update
from rlpractice.algos.marl.envs import eval_marl, make_marl_env
from rlpractice.algos.marl.value import DEFAULTS as VALUE_DEFAULTS, JointReplay, eps_at

DEFAULTS = dict(VALUE_DEFAULTS)
DEFAULTS.update({
    "rounds": 2,
    "hidden": 64,
    "label": "commnet",
})


class CommQNet(th.nn.Module):
    """每个 agent：编码 → R 轮（聚合消息 + 残差更新）→ Q 头。

    use_message=False 时聚合消息恒为 0，但所有投影/更新模块都保留，
    以保证与通信版参数量、深度完全一致（消融只隔离“消息”这一变量）。
    """

    def __init__(self, obs_dim, n_actions, n_agents=2, hidden=64, rounds=2,
                 use_message=True):
        super().__init__()
        self.n_agents = n_agents
        self.hidden = hidden
        self.use_message = use_message
        self.enc = th.nn.Sequential(th.nn.Linear(obs_dim, hidden), th.nn.ReLU())
        self.bcast = th.nn.Linear(hidden, hidden)          # 消息投影（消融版保留）
        self.cells = th.nn.ModuleList([
            th.nn.Sequential(th.nn.Linear(2 * hidden, hidden), th.nn.ReLU(),
                             th.nn.Linear(hidden, hidden))
            for _ in range(rounds)
        ])
        self.head = th.nn.Linear(hidden, n_actions)

    def forward(self, obs, messages=None):
        """obs: (B, n, obs_dim)；messages: 可选 (B, n, hidden) 直接注入的聚合消息。"""
        h = self.enc(obs)                                   # (B, n, h)
        for cell in self.cells:
            if not self.use_message:
                c = th.zeros_like(h)                        # 消融：消息恒 0，深度不变
            elif messages is not None:
                c = messages
            else:
                b = self.bcast(h)                           # 同步轮次：都用上一轮隐状态
                total = b.sum(dim=1, keepdim=True)
                c = (total - b) / (self.n_agents - 1)       # 队友均值（去掉自己）
            h = h + cell(th.cat([h, c], dim=-1))            # 残差更新
        return self.head(h)                                 # (B, n, A)


def _run(use_message: bool, cfg: dict, log) -> dict:
    env_name = str(cfg["env"])
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma = float(cfg["gamma"])
    hidden = int(cfg["hidden"])
    batch = int(cfg["batch_size"])
    rng = np.random.default_rng(seed)
    th.manual_seed(seed)

    env = make_marl_env(env_name, seed=seed)
    obs, _ = env.reset(seed=seed)
    n_agents, obs_dim, n_actions = env.N_AGENTS, env.OBS_DIM, env.N_ACTIONS
    max_steps = env.MAX_STEPS

    net = CommQNet(obs_dim, n_actions, n_agents, hidden,
                   rounds=int(cfg["rounds"]), use_message=use_message)
    tgt = CommQNet(obs_dim, n_actions, n_agents, hidden,
                   rounds=int(cfg["rounds"]), use_message=use_message)
    tgt.load_state_dict(net.state_dict())
    opt = th.optim.Adam(net.parameters(), lr=float(cfg["lr"]))
    replay = JointReplay(int(cfg["replay_capacity"]), n_agents, obs_dim, 1)

    def greedy(o):
        with th.no_grad():
            q = net(th.as_tensor(o[None], dtype=th.float32))[0]
        return q.argmax(1).numpy().astype(np.int64)

    def act(o, eps):
        with th.no_grad():
            q = net(th.as_tensor(o[None], dtype=th.float32))[0].numpy()
        return np.asarray([epsilon_greedy(q[i], eps, rng) for i in range(n_agents)])

    def evaluate(seeds):
        return eval_marl(env_name, greedy, seeds, max_steps)

    env_steps = episode = updates = 0
    next_eval = eval_every
    ep_ret, ep_len = 0.0, 0
    terminated = truncated = False

    while env_steps < budget:
        a = act(obs, eps_at(cfg, env_steps, budget))
        nobs, r, terminated, truncated, info = env.step(a)
        env_steps += 1
        ep_ret += r
        ep_len += 1
        replay.push(obs, a, r, nobs, terminated,
                    np.zeros(1, dtype=np.float32), np.zeros(1, dtype=np.float32))
        obs = nobs

        if replay.n >= int(cfg["warmup"]):
            bd = replay.sample(batch, rng)
            ob = th.as_tensor(bd["obs"])
            ac = th.as_tensor(bd["act"])
            rew = th.as_tensor(bd["rew"])
            nob = th.as_tensor(bd["nobs"])
            don = th.as_tensor(bd["done"])

            q = net(ob)                                   # (B, n, A)
            q_taken = q.gather(2, ac.unsqueeze(-1)).squeeze(-1)
            with th.no_grad():
                qn = tgt(nob)                             # (B, n, A)
                q_next = qn.max(2).values                 # 各自独立 max
                target = rew + gamma * (1.0 - don) * q_next.sum(1)
            loss = th.nn.functional.smooth_l1_loss(q_taken.sum(1), target)

            opt.zero_grad()
            loss.backward()
            th.nn.utils.clip_grad_norm_(net.parameters(), 10.0)
            opt.step()
            updates += 1
            if env_steps % int(cfg["target_sync"]) == 0:
                soft_update(tgt, net, 1.0)

        budget_hit = env_steps >= budget and not (terminated or truncated)
        if terminated or truncated or budget_hit:
            episode += 1
            log.episode(episode, ep_ret, ep_len, env_steps, updates,
                        terminated, truncated or budget_hit)
            obs, _ = env.reset()
            ep_ret, ep_len = 0.0, 0
            terminated = truncated = False

        if env_steps >= next_eval:
            recs = evaluate(range(int(cfg["val_seed_base"]),
                                  int(cfg["val_seed_base"]) + int(cfg["eval_episodes"])))
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

    test_records = evaluate(range(int(cfg["test_seed_base"]),
                                  int(cfg["test_seed_base"]) + int(cfg["test_episodes"])))
    log.evaluate(step=env_steps, policy_mode="greedy", records=test_records)
    th.save({"net": net.state_dict(), "config": dict(cfg)},
            log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")

    from rlpractice.common.evaluate import summarize
    return {"env_steps": env_steps, "episodes": episode, "updates": updates,
            "test": summarize(test_records),
            "n_params": sum(p.numel() for p in net.parameters())}


@register("commnet")
def run_commnet(cfg: dict, log) -> dict:
    return _run(True, cfg, log)


@register("commnet_nomsg")
def run_commnet_nomsg(cfg: dict, log) -> dict:
    return _run(False, cfg, log)
