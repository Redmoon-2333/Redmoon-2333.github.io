"""算法包：导入即注册。train.py 调用 load_all()。"""
from __future__ import annotations

_LOADED = False


def load_all():
    global _LOADED
    if _LOADED:
        return
    from . import single  # noqa: F401
    from . import marl  # noqa: F401
    _LOADED = True
