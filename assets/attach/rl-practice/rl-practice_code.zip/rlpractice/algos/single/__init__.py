"""单智能体算法包：自动发现并导入包内模块，触发 @register 注册。"""
from __future__ import annotations

import importlib
import pkgutil

for _m in pkgutil.iter_modules(__path__):
    importlib.import_module(f"{__name__}.{_m.name}")
del _m, pkgutil, importlib
