"""悬崖变体上的 Q-learning 与 SARSA（表格法）。

对应系列第 2 章：两个算法只差一个词——TD 目标里用 max（想象最优）还是用
实际动作（面对现实）。终止语义见 rlpractice/envs/cliff.py：掉崖即终止是本
变体与 Sutton 标准 CliffWalking 的差异。

bootstrap 约定（全项目统一）：
- terminated（到达目标/掉崖）→ 不 bootstrap，回合边界就是任务边界；
- truncated（100 步人为上限）→ 照常 bootstrap，因为悬崖网格本身是连续任务，
  上限只是采样保护。正文按此口径解释差异。

评估协议（写死在 DEFAULTS，正文按此口径引用）：
- 训练种子 0..4；验证 20 局（10000+）；最终测试 100 局（20000+）。
- 最终测试两种策略模式：greedy（纯贪心）与 stochastic（ε=0.1 采样）。
  同一个 Q 表在两种模式下表现可以差很多——第 11 章“评估协议决定结论”的实例，
  两组数字不得混报。
"""
from __future__ import annotations

import numpy as np

from rlpractice.common.evaluate import evaluate_policy, held_out_seeds, summarize
from rlpractice.common.registry import register
from rlpractice.envs.cliff import N_A, N_S, CliffEnv

DEFAULTS = {
    "alpha": 0.5,
    "gamma": 1.0,
    "eps": 0.1,
    "max_steps": 100,
    "eval_every": None,          # None → budget // 10
    "eval_episodes": 20,
    "test_episodes": 100,
    "val_seed_base": 10000,
    "test_seed_base": 20000,
}


def epsilon_greedy(q_row: np.ndarray, eps: float, rng: np.random.Generator) -> int:
    """ε-greedy；平局由 np.argmax 固定到动作 0（与源教学代码一致，正文注明）。"""
    if rng.random() < eps:
        return int(rng.integers(N_A))
    return int(np.argmax(q_row))


def qlearning_update(Q, s, a, r, s2, terminated, alpha, gamma):
    target = r if terminated else r + gamma * np.max(Q[s2])
    Q[s, a] += alpha * (target - Q[s, a])


def sarsa_update(Q, s, a, r, s2, a2, terminated, alpha, gamma):
    target = r if terminated else r + gamma * Q[s2, a2]
    Q[s, a] += alpha * (target - Q[s, a])


def _run(algo: str, cfg: dict, log) -> dict:
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    alpha, gamma, eps = float(cfg["alpha"]), float(cfg["gamma"]), float(cfg["eps"])
    max_steps = int(cfg["max_steps"])

    rng = np.random.default_rng(seed)
    env = CliffEnv(max_steps=max_steps, seed=seed)
    eval_env = CliffEnv(max_steps=max_steps, seed=seed)

    Q = np.zeros((N_S, N_A), dtype=np.float64)
    env_steps = episode = updates = 0
    next_eval = eval_every

    s, _ = env.reset(seed=seed)
    while env_steps < budget:
        a = epsilon_greedy(Q[s], eps, rng)
        ret, length, terminated, truncated = 0.0, 0, False, False

        while not (terminated or truncated) and env_steps < budget:
            s2, r, terminated, truncated, _ = env.step(a)
            ret += r
            length += 1
            env_steps += 1

            if algo == "qlearning":
                qlearning_update(Q, s, a, r, s2, terminated, alpha, gamma)
                s = s2
                if not (terminated or truncated):
                    a = epsilon_greedy(Q[s], eps, rng)
            else:  # SARSA：先在 s2 采样实际动作，再更新
                if terminated:
                    sarsa_update(Q, s, a, r, s2, a, terminated, alpha, gamma)
                    s = s2
                else:
                    a_next = epsilon_greedy(Q[s2], eps, rng)
                    sarsa_update(Q, s, a, r, s2, a_next, terminated, alpha, gamma)
                    s, a = s2, a_next

        episode += 1
        updates += 1
        log.episode(episode, ret, length, env_steps, updates, terminated, truncated)

        if env_steps >= next_eval:
            greedy_fn = lambda o, q=Q: int(np.argmax(q[o]))
            recs = evaluate_policy(
                eval_env, greedy_fn,
                held_out_seeds(int(cfg["val_seed_base"]), int(cfg["eval_episodes"])),
                max_steps)
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

        if env_steps < budget:
            s, _ = env.reset()

    # 最终测试：两种策略模式分别落盘，不混报
    greedy_fn = lambda o, q=Q: int(np.argmax(q[o]))
    stochastic_rng = np.random.default_rng(int(cfg["test_seed_base"]))  # 跨步共享，勿每次重播种
    stochastic_fn = lambda o, q=Q, r=stochastic_rng: epsilon_greedy(q[o], eps, r)
    test_seeds = held_out_seeds(int(cfg["test_seed_base"]), int(cfg["test_episodes"]))
    results = {}
    for mode, fn in (("greedy", greedy_fn), ("stochastic", stochastic_fn)):
        recs = evaluate_policy(eval_env, fn, test_seeds, max_steps)
        log.evaluate(step=env_steps, policy_mode=mode, records=recs)
        results[mode] = summarize(recs)

    np.savez(log.run_dir / "checkpoints" / "q_table.npz", q=Q)
    log.finish("completed")
    return {
        "algo": algo,
        "env_steps": env_steps,
        "episodes": episode,
        "updates": updates,
        "test": results,
        "policy_map": _policy_map(Q),
    }


def _policy_map(Q) -> str:
    from rlpractice.envs.cliff import ACTION_NAMES, CLIFF, COLS, GOAL, ROWS, to_cell
    cells = []
    for s in range(N_S):
        c = to_cell(s)
        if c == GOAL:
            cells.append("G")
        elif c in CLIFF:
            cells.append("▓")
        else:
            cells.append(ACTION_NAMES[int(np.argmax(Q[s]))])
    return "\n".join(" ".join(cells[r * COLS:(r + 1) * COLS]) for r in range(ROWS))


@register("qlearning")
def run_qlearning(cfg: dict, log) -> dict:
    return _run("qlearning", cfg, log)


@register("sarsa")
def run_sarsa(cfg: dict, log) -> dict:
    return _run("sarsa", cfg, log)


run_qlearning.DEFAULTS = DEFAULTS
run_sarsa.DEFAULTS = DEFAULTS
