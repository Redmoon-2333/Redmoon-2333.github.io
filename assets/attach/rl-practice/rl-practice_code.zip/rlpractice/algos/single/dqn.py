"""DQN（CartPole-v1）——系列第 3 章：从 Q 表到函数逼近。

要点与本项目的口径：
- 经验回放 + 目标网络：打破样本相关性、稳定 bootstrap 目标；
- terminated（杆倒下）→ 目标不含下一状态项；truncated（撑满 500 步）→ 照常
  bootstrap（人为上限，不是任务终点），与全项目约定一致；
- 训练带探索（ε 衰减），评估用贪心，两者不混报；
- success := 撑满时限（truncated 且未 terminated），fell := 杆倒下。
"""
from __future__ import annotations

import gymnasium as gym
import numpy as np
import torch as th
import torch.nn as nn

from rlpractice.common.evaluate import evaluate_policy, held_out_seeds, summarize
from rlpractice.common.registry import register

DEFAULTS = {
    "hidden": 128,
    "lr": 1e-3,
    "gamma": 0.99,
    "replay_capacity": 50000,
    "batch_size": 32,
    "target_sync": 500,
    "warmup": 1000,
    "eps_start": 1.0,
    "eps_end": 0.05,
    "eps_decay_steps": 10000,
    "grad_clip": 10.0,
    "eval_every": None,          # None → budget // 10
    "eval_episodes": 20,
    "test_episodes": 100,
    "val_seed_base": 10000,
    "test_seed_base": 20000,
    "device": "cpu",
}
# v2（2026-09-26 配置冻结）：v1 的 ε 衰减 50k/批 64/同步 1000 在 100k 步内
# 只学到 ~95 步；探针显示 ε 10k 衰减 + batch 32 + target 500 可在同预算内
# 解决 CartPole。调参过程接触过原测试种子，最终正文数字以 scripts/final_eval.py
# 在 30000+ 新种子上的一次性复评为准（见第 11 章披露）。


class SuccessWrapper(gym.Wrapper):
    """把 CartPole 的结束语义翻译成统一记录字段。"""

    def step(self, action):
        obs, r, term, trunc, info = self.env.step(action)
        info = dict(info)
        info["success"] = bool(trunc and not term)
        info["fell"] = bool(term)
        return obs, r, term, trunc, info


def make_env() -> gym.Env:
    return SuccessWrapper(gym.make("CartPole-v1"))


def build_net(hidden: int) -> nn.Module:
    return nn.Sequential(
        nn.Linear(4, hidden), nn.ReLU(),
        nn.Linear(hidden, hidden), nn.ReLU(),
        nn.Linear(hidden, 2),
    )


class Replay:
    """定容经验回放；d=1 表示 terminated（TD 目标不外推）。"""

    def __init__(self, capacity: int):
        self.cap = capacity
        self.s = np.zeros((capacity, 4), dtype=np.float32)
        self.a = np.zeros(capacity, dtype=np.int64)
        self.r = np.zeros(capacity, dtype=np.float32)
        self.s2 = np.zeros((capacity, 4), dtype=np.float32)
        self.d = np.zeros(capacity, dtype=np.float32)
        self.n = 0
        self.i = 0

    def push(self, s, a, r, s2, done_terminal):
        self.s[self.i] = s
        self.a[self.i] = a
        self.r[self.i] = r
        self.s2[self.i] = s2
        self.d[self.i] = float(done_terminal)
        self.i = (self.i + 1) % self.cap
        self.n = min(self.n + 1, self.cap)

    def sample(self, batch: int, rng: np.random.Generator):
        idx = rng.integers(0, self.n, size=batch)
        return self.s[idx], self.a[idx], self.r[idx], self.s2[idx], self.d[idx]


@register("dqn")
def run(cfg: dict, log) -> dict:
    seed = int(cfg["seed"])
    budget = int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    device = th.device(cfg.get("device", "cpu"))

    th.manual_seed(seed)
    rng = np.random.default_rng(seed)

    net = build_net(int(cfg["hidden"])).to(device)
    target = build_net(int(cfg["hidden"])).to(device)
    target.load_state_dict(net.state_dict())
    opt = th.optim.Adam(net.parameters(), lr=float(cfg["lr"]))
    loss_fn = nn.SmoothL1Loss()
    replay = Replay(int(cfg["replay_capacity"]))

    env = make_env()
    eval_env = make_env()

    def train_action(obs, eps):
        if rng.random() < eps:
            return int(rng.integers(2))
        with th.no_grad():
            return int(net(th.as_tensor(obs, dtype=th.float32, device=device)).argmax().item())

    def greedy(obs):
        with th.no_grad():
            return int(net(th.as_tensor(obs, dtype=th.float32, device=device)).argmax().item())

    def eps_at(step: int) -> float:
        frac = min(1.0, step / max(1, int(cfg["eps_decay_steps"])))
        return float(cfg["eps_start"]) + frac * (float(cfg["eps_end"]) - float(cfg["eps_start"]))

    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)
    ep_ret, ep_len = 0.0, 0

    while env_steps < budget:
        a = train_action(obs, eps_at(env_steps))
        obs2, r, term, trunc, info = env.step(a)
        env_steps += 1
        ep_ret += r
        ep_len += 1
        replay.push(obs, a, r, obs2, done_terminal=term)
        obs = obs2

        if replay.n >= int(cfg["warmup"]):
            bs, ba, br, bs2, bd = replay.sample(int(cfg["batch_size"]), rng)
            bs_t = th.as_tensor(bs, device=device)
            ba_t = th.as_tensor(ba, device=device)
            br_t = th.as_tensor(br, device=device)
            bs2_t = th.as_tensor(bs2, device=device)
            bd_t = th.as_tensor(bd, device=device)

            q = net(bs_t).gather(1, ba_t[:, None]).squeeze(1)
            with th.no_grad():
                q_next = target(bs2_t).max(1).values
                y = br_t + float(cfg["gamma"]) * q_next * (1.0 - bd_t)
            loss = loss_fn(q, y)
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), float(cfg["grad_clip"]))
            opt.step()
            updates += 1
            if env_steps % int(cfg["target_sync"]) == 0:
                target.load_state_dict(net.state_dict())

        budget_hit = env_steps >= budget and not (term or trunc)
        if term or trunc or budget_hit:
            episode += 1
            log.episode(episode, ep_ret, ep_len, env_steps, updates,
                        term, trunc or budget_hit)
            obs, _ = env.reset()
            ep_ret, ep_len = 0.0, 0

        if env_steps >= next_eval:
            recs = evaluate_policy(eval_env, greedy,
                                   held_out_seeds(int(cfg["val_seed_base"]),
                                                  int(cfg["eval_episodes"])),
                                   max_steps=600)
            log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
            next_eval = env_steps + eval_every

    test_records = evaluate_policy(
        eval_env, greedy,
        held_out_seeds(int(cfg["test_seed_base"]), int(cfg["test_episodes"])),
        max_steps=600)
    log.evaluate(step=env_steps, policy_mode="greedy", records=test_records)

    th.save({"policy": net.state_dict(), "target": target.state_dict(),
             "config": {k: v for k, v in cfg.items()}},
            log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")
    return {
        "env_steps": env_steps, "episodes": episode, "updates": updates,
        "test": summarize(test_records),
    }
