"""策略梯度类单智能体算法（CartPole-v1）：REINFORCE、A2C、PPO-Clip。

对应系列第 4–5 章。三者共用同一环境包装与评估协议，差别只在**用什么信号、
在什么时机更新**：

- REINFORCE：回合结束后用整条回报做一次更新，方差大；
- A2C：每 5 步用 GAE 做 actor-critic 更新，学会了边走边学；
- PPO-Clip：在同一批数据上多轮更新，用概率比裁剪限制步子——
  裁剪的是代理目标，不是对概率比的硬约束（源讲义的错误说法，正文要更正）。

终止/截断口径与 dqn.py 一致：杆倒下 terminated 不 bootstrap；撑满 500 步
truncated 照常 bootstrap；但 GAE 的 λ 链在两种回合结束处都切断。
"""
from __future__ import annotations

import gymnasium as gym
import numpy as np
import torch as th
import torch.nn as nn

from rlpractice.common.evaluate import evaluate_policy, held_out_seeds, summarize
from rlpractice.common.registry import register
from rlpractice.algos.single.dqn import make_env

EVAL = {
    "eval_every": None,          # None → budget // 10
    "eval_episodes": 20,
    "test_episodes": 100,
    "val_seed_base": 10000,
    "test_seed_base": 20000,
}

REINFORCE_DEFAULTS = dict(EVAL, hidden=128, lr=1e-3, gamma=0.99,
                          baseline="moving", baseline_beta=0.9)
A2C_DEFAULTS = dict(EVAL, hidden=128, lr=1e-3, gamma=0.99, gae_lambda=0.95,
                    rollout=32, ent_coef=0.001, vf_coef=0.5, grad_clip=5.0,
                    normalize_adv=False)
# v2（2026-09-26 配置冻结）：v1（rollout5/lr3e-4/ent0.01/clip0.5/批内归一化）
# 在 100k 步内只有 ~33 步。三处调整各自的原因：
#   · 批内优势归一化在 5–32 样本上会把噪声放大成满量级信号 → 默认关闭；
#   · clip 0.5 卡死了原始量级（数百步回报）的优势，放宽到 5.0 后可解；
#   · rollout32/lr1e-3/ent0.001 让每批信号更稳。调参探针接触过原测试种子，
#     正文数字以 scripts/final_eval.py 的 30000+ 新种子复评为准。
PPO_DEFAULTS = dict(EVAL, hidden=64, lr=3e-4, gamma=0.99, gae_lambda=0.95,
                    rollout=512, epochs=4, minibatch=64, clip=0.2,
                    ent_coef=0.01, vf_coef=0.5, grad_clip=0.5)


# ------------------------------------------------------------------ 公共工具
def discounted_returns(rewards, gamma):
    out = np.zeros(len(rewards), dtype=np.float32)
    g = 0.0
    for t in range(len(rewards) - 1, -1, -1):
        g = rewards[t] + gamma * g
        out[t] = g
    return out


def gae(rewards, values, terminated_flags, end_flags, last_value, gamma, lam,
        next_vals=None):
    """GAE(λ)。

    - `terminated_flags[t]`：该步真实终止 → 下一状态价值不参与 bootstrap；
    - `end_flags[t]`：回合结束（含截断）→ λ 链在此切断，但截断处仍用
      下一状态价值做一步 bootstrap；
    - `next_vals[t]`：可选，逐步给出“该步之后的 bootstrap 价值”。给了它就
      不再依赖 `values[t+1]`——否则回合中段的截断会错误地取到**新回合**
      初始状态的价值。未给时回退到 `values[t+1]` / `last_value` 的旧语义。
    返回 (advantages, returns)。
    """
    adv = np.zeros(len(rewards), dtype=np.float32)
    g = 0.0
    for t in range(len(rewards) - 1, -1, -1):
        if next_vals is not None:
            bootstrap = 0.0 if terminated_flags[t] else float(next_vals[t])
        else:
            next_val = last_value if t == len(rewards) - 1 else values[t + 1]
            bootstrap = 0.0 if terminated_flags[t] else next_val
        delta = rewards[t] + gamma * bootstrap - values[t]
        g = delta + gamma * lam * (0.0 if end_flags[t] else 1.0) * g
        adv[t] = g
    returns = adv + np.asarray(values, dtype=np.float32)
    return adv, returns


def ppo_surrogate(ratio, adv, clip):
    """PPO-Clip 的代理目标（取负即要最小化的损失）。

    裁剪只作用在代理目标上：|ratio−1| 超出区间后该样本梯度为 0，
    但 ratio 本身仍可自由变化——不是对概率比的硬约束。
    """
    surr1 = ratio * adv
    surr2 = th.clamp(ratio, 1 - clip, 1 + clip) * adv
    return -th.min(surr1, surr2)


class ActorCritic(nn.Module):
    def __init__(self, hidden, n_actions=2):
        super().__init__()
        self.trunk = nn.Sequential(nn.Linear(4, hidden), nn.ReLU(),
                                   nn.Linear(hidden, hidden), nn.ReLU())
        self.pi = nn.Linear(hidden, n_actions)
        self.v = nn.Linear(hidden, 1)

    def forward(self, obs):
        h = self.trunk(obs)
        return self.pi(h), self.v(h).squeeze(-1)


def greedy_action(model, obs):
    with th.no_grad():
        logits, _ = model(th.as_tensor(obs[None], dtype=th.float32))
        return int(logits.argmax(dim=-1).item())


def run_protocol(log, cfg, model, act_fn, env_steps, episodes, updates, extra=None):
    """统一收尾：最终测试 100 局 greedy → checkpoint → completed → summary。"""
    eval_env = make_env()
    recs = evaluate_policy(eval_env, act_fn,
                           held_out_seeds(int(cfg["test_seed_base"]),
                                          int(cfg["test_episodes"])),
                           max_steps=600)
    log.evaluate(step=env_steps, policy_mode="greedy", records=recs)
    ckpt = {"state_dict": model.state_dict(), "config": dict(cfg)}
    if extra:
        ckpt.update(extra)
    th.save(ckpt, log.run_dir / "checkpoints" / "final.pt")
    log.finish("completed")
    return {"env_steps": env_steps, "episodes": episodes, "updates": updates,
            "test": summarize(recs)}


def eval_and_log(log, cfg, model, eval_env, act_fn, env_steps):
    recs = evaluate_policy(eval_env, act_fn,
                           held_out_seeds(int(cfg["val_seed_base"]),
                                          int(cfg["eval_episodes"])),
                           max_steps=600)
    log.evaluate(step=env_steps, policy_mode="greedy", records=recs)


# ------------------------------------------------------------------ REINFORCE
@register("reinforce", defaults=REINFORCE_DEFAULTS)
def run_reinforce(cfg: dict, log) -> dict:
    seed, budget = int(cfg["seed"]), int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma = float(cfg["gamma"])
    th.manual_seed(seed)
    rng = np.random.default_rng(seed)

    model = nn.Sequential(nn.Linear(4, int(cfg["hidden"])), nn.ReLU(),
                          nn.Linear(int(cfg["hidden"]), int(cfg["hidden"])), nn.ReLU(),
                          nn.Linear(int(cfg["hidden"]), 2))
    opt = th.optim.Adam(model.parameters(), lr=float(cfg["lr"]))
    env, eval_env = make_env(), make_env()

    baseline = 0.0
    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)

    def greedy(o, m=model):
        with th.no_grad():
            return int(m(th.as_tensor(o[None], dtype=th.float32)).argmax(dim=-1).item())

    while env_steps < budget:
        logps, rewards, terminated = [], [], []
        ep_ret, ep_len, term, trunc = 0.0, 0, False, False
        while not (term or trunc) and env_steps < budget:
            logits = model(th.as_tensor(obs[None], dtype=th.float32))[0]
            dist = th.distributions.Categorical(logits=logits)
            a = int(dist.sample())
            obs2, r, term, trunc, info = env.step(a)
            logps.append(dist.log_prob(th.tensor(a)))
            rewards.append(float(r))
            terminated.append(term)
            obs = obs2
            env_steps += 1
            ep_ret += r
            ep_len += 1

        budget_hit = env_steps >= budget and not (term or trunc)
        G = discounted_returns(rewards, gamma)
        if cfg["baseline"] == "moving":
            b = baseline
            baseline = float(cfg["baseline_beta"]) * baseline + \
                (1 - float(cfg["baseline_beta"])) * float(np.mean(G))
        else:
            b = 0.0
        adv = th.as_tensor(G - b, dtype=th.float32)
        loss = -(adv * th.stack(logps)).mean()
        opt.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 10.0)
        opt.step()
        updates += 1

        episode += 1
        log.episode(episode, ep_ret, ep_len, env_steps, updates, term, trunc or budget_hit)
        obs, _ = env.reset()

        if env_steps >= next_eval:
            eval_and_log(log, cfg, model, eval_env, greedy, env_steps)
            next_eval = env_steps + eval_every

    return run_protocol(log, cfg, model, greedy, env_steps, episode, updates)


# ---------------------------------------------------------------------- A2C
@register("a2c", defaults=A2C_DEFAULTS)
def run_a2c(cfg: dict, log) -> dict:
    seed, budget = int(cfg["seed"]), int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma, lam = float(cfg["gamma"]), float(cfg["gae_lambda"])
    th.manual_seed(seed)
    rng = np.random.default_rng(seed)

    model = ActorCritic(int(cfg["hidden"]))
    opt = th.optim.Adam(model.parameters(), lr=float(cfg["lr"]))
    env, eval_env = make_env(), make_env()

    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)
    last_state = obs            # 截断处 bootstrap 用的“回合末状态”（reset 之前）

    ep_ret, ep_len = 0.0, 0          # 跨 rollout 累计（在回合结束时才落盘）
    while env_steps < budget:
        obs_buf, act_buf, rew_buf, val_buf, logp_buf = [], [], [], [], []
        term_buf, end_buf, next_val_buf = [], [], []
        steps_in_rollout = 0

        while steps_in_rollout < int(cfg["rollout"]) and env_steps < budget:
            with th.no_grad():
                logits, v = model(th.as_tensor(obs[None], dtype=th.float32))
                dist = th.distributions.Categorical(logits=logits)
                a = int(dist.sample())
                logp = dist.log_prob(th.tensor(a))
            obs2, r, term, trunc, info = env.step(a)
            env_steps += 1
            steps_in_rollout += 1
            ep_ret += r
            ep_len += 1
            with th.no_grad():
                vn = 0.0 if term else float(
                    model(th.as_tensor(obs2[None], dtype=th.float32))[1])

            obs_buf.append(obs); act_buf.append(a); rew_buf.append(float(r))
            val_buf.append(float(v)); logp_buf.append(logp)
            term_buf.append(term); end_buf.append(term or trunc)
            next_val_buf.append(vn)
            obs = obs2

            if term or trunc or env_steps >= budget:
                episode += 1
                budget_hit = env_steps >= budget and not (term or trunc)
                log.episode(episode, ep_ret, ep_len, env_steps, updates,
                            term, trunc or budget_hit)
                if term or trunc:
                    obs, _ = env.reset()
                ep_ret, ep_len = 0.0, 0

        adv, rets = gae(rew_buf, val_buf, term_buf, end_buf, last_value=0.0,
                        gamma=gamma, lam=lam, next_vals=next_val_buf)
        adv_t = th.as_tensor(adv, dtype=th.float32)
        if cfg.get("normalize_adv", False):
            # 小批量上按批内 std 归一化会把噪声放大成满量级信号，默认关闭
            adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)
        obs_t = th.as_tensor(np.asarray(obs_buf), dtype=th.float32)
        act_t = th.as_tensor(np.asarray(act_buf), dtype=th.int64)

        logits, v = model(obs_t)
        dist = th.distributions.Categorical(logits=logits)
        pg_loss = -(dist.log_prob(act_t) * adv_t).mean()
        vf_loss = nn.functional.mse_loss(v, th.as_tensor(rets))
        ent = dist.entropy().mean()
        loss = pg_loss + float(cfg["vf_coef"]) * vf_loss - float(cfg["ent_coef"]) * ent
        opt.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), float(cfg["grad_clip"]))
        opt.step()
        updates += 1

        if env_steps >= next_eval:
            eval_and_log(log, cfg, model, eval_env,
                         lambda o, m=model: greedy_action(m, o), env_steps)
            next_eval = env_steps + eval_every

    return run_protocol(log, cfg, model, lambda o, m=model: greedy_action(m, o),
                        env_steps, episode, updates)


# ---------------------------------------------------------------------- PPO
@register("ppo", defaults=PPO_DEFAULTS)
def run_ppo(cfg: dict, log) -> dict:
    seed, budget = int(cfg["seed"]), int(cfg["budget"])
    eval_every = int(cfg.get("eval_every") or max(1, budget // 10))
    gamma, lam, clip = float(cfg["gamma"]), float(cfg["gae_lambda"]), float(cfg["clip"])
    th.manual_seed(seed)
    rng = np.random.default_rng(seed)

    model = ActorCritic(int(cfg["hidden"]))
    opt = th.optim.Adam(model.parameters(), lr=float(cfg["lr"]))
    env, eval_env = make_env(), make_env()

    env_steps = episode = updates = 0
    next_eval = eval_every
    obs, _ = env.reset(seed=seed)
    last_state = obs

    ep_ret, ep_len = 0.0, 0          # 跨 rollout 累计
    while env_steps < budget:
        # ---- 收集 rollout（no_grad，行为策略快照）----
        obs_buf, act_buf, rew_buf, val_buf, logp_buf = [], [], [], [], []
        term_buf, end_buf, next_val_buf = [], [], []
        while len(obs_buf) < int(cfg["rollout"]) and env_steps < budget:
            with th.no_grad():
                logits, v = model(th.as_tensor(obs[None], dtype=th.float32))
                dist = th.distributions.Categorical(logits=logits)
                a = int(dist.sample())
                logp = dist.log_prob(th.tensor(a))
            obs2, r, term, trunc, info = env.step(a)
            env_steps += 1
            with th.no_grad():
                vn = 0.0 if term else float(
                    model(th.as_tensor(obs2[None], dtype=th.float32))[1])
            obs_buf.append(obs); act_buf.append(a); rew_buf.append(float(r))
            val_buf.append(float(v)); logp_buf.append(logp)
            term_buf.append(term); end_buf.append(term or trunc)
            next_val_buf.append(vn)
            obs = obs2
            ep_ret += r
            ep_len += 1

            if term or trunc:
                episode += 1
                log.episode(episode, ep_ret, ep_len, env_steps, updates, term, trunc)
                obs, _ = env.reset()
                ep_ret, ep_len = 0.0, 0
            elif env_steps >= budget:
                episode += 1
                log.episode(episode, ep_ret, ep_len, env_steps, updates, False, True)
                break

        adv, rets = gae(rew_buf, val_buf, term_buf, end_buf, last_value=0.0,
                        gamma=gamma, lam=lam, next_vals=next_val_buf)

        obs_t = th.as_tensor(np.asarray(obs_buf), dtype=th.float32)
        act_t = th.as_tensor(np.asarray(act_buf), dtype=th.int64)
        old_logp_t = th.stack([lp.clone() for lp in logp_buf]).detach()
        adv_t = th.as_tensor(adv, dtype=th.float32)
        ret_t = th.as_tensor(rets, dtype=th.float32)
        adv_norm = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)

        n = obs_t.shape[0]
        idx = th.arange(n)
        diag_kl, diag_cf = [], []
        for _ in range(int(cfg["epochs"])):
            perm = idx[th.randperm(n)]
            for start in range(0, n, int(cfg["minibatch"])):
                mb = perm[start:start + int(cfg["minibatch"])]
                logits, v = model(obs_t[mb])
                dist = th.distributions.Categorical(logits=logits)
                new_logp = dist.log_prob(act_t[mb])
                ratio = th.exp(new_logp - old_logp_t[mb])
                pg_loss = ppo_surrogate(ratio, adv_norm[mb], clip).mean()
                vf_loss = nn.functional.mse_loss(v, ret_t[mb])
                ent = dist.entropy().mean()
                loss = pg_loss + float(cfg["vf_coef"]) * vf_loss - float(cfg["ent_coef"]) * ent
                opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), float(cfg["grad_clip"]))
                opt.step()
                with th.no_grad():
                    lr = ratio
                    diag_kl.append(float(((lr - 1) - th.log(lr)).mean()))
                    diag_cf.append(float((th.abs(lr - 1) > clip).float().mean()))
        updates += 1
        log.event("ppo_diag", step=env_steps,
                  approx_kl=float(np.mean(diag_kl)), clip_frac=float(np.mean(diag_cf)))

        if env_steps >= next_eval:
            eval_and_log(log, cfg, model, eval_env,
                         lambda o, m=model: greedy_action(m, o), env_steps)
            next_eval = env_steps + eval_every

    return run_protocol(log, cfg, model, lambda o, m=model: greedy_action(m, o),
                        env_steps, episode, updates)
