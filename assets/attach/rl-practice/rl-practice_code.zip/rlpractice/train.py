"""统一训练 CLI。

    python -m rlpractice.train --algo qlearning --env cliff --seed 0 --budget 100000

配置优先级：算法默认值 < --set key=value 覆盖。所有运行落盘到 runs/。
"""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from pathlib import Path

from rlpractice.common import registry
from rlpractice.common.runlog import RunLogger


def load_algos():
    """惰性导入所有算法模块以触发注册。"""
    from rlpractice.algos import load_all
    load_all()


def parse_set(pairs):
    out = {}
    for kv in pairs or []:
        if "=" not in kv:
            raise SystemExit(f"--set 需要 key=value 形式，收到 {kv!r}")
        k, v = kv.split("=", 1)
        try:
            out[k] = json.loads(v)
        except json.JSONDecodeError:
            out[k] = v
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description="rl-practice 训练入口")
    p.add_argument("--algo", required=True, help="算法名，见 --list")
    p.add_argument("--env", required=True, help="环境名（cliff/cartpole/corridor/riddle/nav2d）")
    p.add_argument("--seed", type=int, default=0, help="训练种子")
    p.add_argument("--budget", type=int, required=True, help="环境步（联合步）预算")
    p.add_argument("--runs-root", default=str(Path(__file__).resolve().parents[1] / "runs"))
    p.add_argument("--set", action="append", default=[], metavar="KEY=VALUE",
                   help="覆盖算法配置，可重复")
    p.add_argument("--list", action="store_true", help="列出已注册算法")
    args = p.parse_args(argv)

    load_algos()
    if args.list:
        print("\n".join(registry.names()))
        return 0

    run_fn = registry.get(args.algo)
    cfg = registry.get_defaults(args.algo)
    cfg.update(parse_set(args.set))
    # CLI 的四个核心参数始终生效，不被 --set 覆盖
    cfg.update(algo=args.algo, env=args.env, seed=args.seed, budget=args.budget)

    log = RunLogger(args.runs_root, env=args.env, algo=args.algo,
                    seed=args.seed, config=cfg)
    print(f"[run] {log.run_dir}")
    print(f"[cfg] {json.dumps(cfg, ensure_ascii=False)}")
    try:
        with log:
            summary = run_fn(cfg, log)
    except BaseException:
        traceback.print_exc()
        print(f"[fail] 日志保留在 {log.run_dir}", file=sys.stderr)
        return 1
    print(f"[done] {json.dumps(summary, ensure_ascii=False, default=str)}")
    print(f"[out ] {log.run_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
