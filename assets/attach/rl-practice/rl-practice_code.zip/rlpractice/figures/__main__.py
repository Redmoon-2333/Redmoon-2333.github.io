from rlpractice.figures import main

raise SystemExit(main())
