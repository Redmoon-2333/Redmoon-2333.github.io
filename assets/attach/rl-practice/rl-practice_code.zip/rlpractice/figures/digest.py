"""把 runs/ 的原始结果汇总成写作用的数字摘要（内部文件，不是图）。

    python -m rlpractice.figures.digest --out <path>/数据摘要.md

只读运行产物；缺种子的组标 “不完整”，不给可引用数字。
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import defaultdict
from pathlib import Path

from rlpractice.common.runlog import find_runs, read_run
from rlpractice.common.stats import mean, std_sample


def _flag(v) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes")


def read_final_eval(run) -> list | None:
    """一次性复评记录（30000+ 新种子）；存在则优先于常规测试行。"""
    if "final_eval" not in run["manifest"]:
        return None
    p = Path(run["dir"]) / "final_eval.csv"
    if not p.exists():
        return None
    with open(p, newline="", encoding="utf-8") as f:
        rows = []
        for r in csv.DictReader(f):
            rows.append({
                "env_seed": int(r["env_seed"]), "return": float(r["return"]),
                "length": int(r["length"]), "success": _flag(r["success"]),
                "fell": _flag(r["fell"]), "truncated": _flag(r["truncated"]),
            })
    return rows

PR_ROOT = Path(__file__).resolve().parents[2]
RUNS = PR_ROOT / "runs"

GROUPS = [
    ("cliff", ["qlearning", "sarsa"], ["greedy", "stochastic"]),
    ("cartpole", ["dqn", "reinforce", "a2c", "ppo"], ["greedy"]),
    ("corridor", ["iql", "vdn", "qmix", "coma"], ["greedy"]),
    ("riddle", ["commnet", "commnet_nomsg", "iql"], ["greedy"]),
    ("nav2d", ["maddpg", "iddpg"], ["greedy"]),
]

# 个别算法额外记录的评估模式
EXTRA_MODES = {("corridor", "coma"): ["stochastic"]}


def final_records(run, mode):
    """最终测试记录：只取测试种子段（排除与之重合的验证点）。"""
    base = int(run["manifest"]["config"].get("test_seed_base", 20000))
    rows = [r for r in run["evals"]
            if r["policy_mode"] == mode and r["env_seed"] >= base]
    if not rows:
        return None
    last = max(r["step"] for r in rows)
    return [r for r in rows if r["step"] == last]


def summarize_records(recs):
    rets = [r["return"] for r in recs]
    n = len(recs)
    return {
        "n": n,
        "return_mean": mean(rets),
        "return_sd": std_sample(rets),
        "success_rate": sum(r["success"] for r in recs) / n,
        "fell_rate": sum(r["fell"] for r in recs) / n,
        "trunc_rate": sum(r["truncated"] for r in recs) / n,
        "length_mean": mean([r["length"] for r in recs]),
    }


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(PR_ROOT.parent.parent / "08_MyNote" / "强化学习实践" / "实验" / "数据摘要.md"))
    p.add_argument("--runs-root", default=str(RUNS))
    p.add_argument("--expect-seeds", type=int, default=5)
    args = p.parse_args(argv)
    runs_root = Path(args.runs_root)
    expect = args.expect_seeds

    lines = ["# 强化学习实践系列 · 实测数据摘要（内部）", "",
             f"- 运行目录：`{runs_root}`",
             "- 口径：误差为跨训练种子的样本 SD；最终测试为保留测试种子上的逐局原始记录。",
             "- 「不完整」的组没有可引用数字，必须补跑或在正文说明缺失。", ""]
    problems = []

    for env, algos, modes in GROUPS:
        lines.append(f"## {env}")
        lines.append("")
        for algo in algos:
            dirs = find_runs(runs_root, env=env, algo=algo, status="completed")
            by_seed = {}
            for d in dirs:
                run = read_run(d)
                s = run["manifest"]["seed"]
                if s not in by_seed or run["manifest"]["finished_at"] > by_seed[s]["manifest"]["finished_at"]:
                    by_seed[s] = run
            missing = [s for s in range(expect) if s not in by_seed]
            cfg = by_seed[0]["manifest"]["config"] if by_seed else {}
            lines.append(f"### {algo}")
            lines.append("")
            algo_modes = list(modes) + list(EXTRA_MODES.get((env, algo), []))
            if missing:
                msg = f"不完整：缺种子 {missing}（已有 {sorted(by_seed)}）"
                lines.append(f"- {msg}")
                problems.append(f"{env}/{algo}: {msg}")
                lines.append("")
                continue
            budgets = {by_seed[s]["manifest"]["config"].get("budget") for s in range(expect)}
            walls = [by_seed[s]["manifest"].get("wall_seconds") for s in range(expect)]
            eps = sum(len(by_seed[s]["episodes"]) for s in range(expect))
            steps = {by_seed[s]["episodes"][-1]["env_steps"] for s in range(expect) if by_seed[s]["episodes"]}
            lines.append(f"- 预算：{budgets}（各种子实际末步 {steps}），总回合 {eps}，"
                         f"墙钟 {mean([w for w in walls if w is not None]):.0f}s ± "
                         f"{std_sample([w for w in walls if w is not None]):.0f}s")
            lines.append(f"- 关键超参：`{ {k: cfg[k] for k in sorted(cfg) if k not in ('algo','env','seed')} }`")
            for mode in algo_modes:
                stats = []
                fresh = 0
                for s in range(expect):
                    recs = read_final_eval(by_seed[s]) if mode == "greedy" else None
                    if recs is not None:
                        fresh += 1
                    else:
                        recs = final_records(by_seed[s], mode)
                    if not recs:
                        problems.append(f"{env}/{algo}/seed{s}: 无 {mode} 最终评估")
                        continue
                    stats.append(summarize_records(recs))
                if len(stats) < expect:
                    lines.append(f"- 最终测试[{mode}]：数据缺失")
                    continue
                label = (f"最终测试[{mode}·复评 seeds 30000+]" if fresh == expect
                         else f"最终测试[{mode}]")
                lines.append(
                    f"- {label}（每种子 {stats[0]['n']} 局 × 5 种子）："
                    f"return {mean([x['return_mean'] for x in stats]):.3f} ± "
                    f"{std_sample([x['return_mean'] for x in stats]):.3f}；"
                    f"成功率 {100 * mean([x['success_rate'] for x in stats]):.1f}%；"
                    f"掉崖率 {100 * mean([x['fell_rate'] for x in stats]):.1f}%；"
                    f"截断率 {100 * mean([x['trunc_rate'] for x in stats]):.1f}%；"
                    f"局长 {mean([x['length_mean'] for x in stats]):.1f}")
                if fresh == expect:
                    per_seed = [f"s{s}:{stats[s]['return_mean']:.0f}" for s in range(expect)]
                    lines.append(f"- 逐种子 return：{'、'.join(per_seed)}")
            # 评估曲线首末点（用于“从多少到多少”的表述）
            for key_name, key in (("成功率", "success"), ("平均回报", "return")):
                first_last = []
                for s in range(expect):
                    cfg = by_seed[s]["manifest"]["config"]
                    val_base = int(cfg.get("val_seed_base", 10000))
                    val_count = int(cfg.get("eval_episodes", 20))
                    rows = [r for r in by_seed[s]["evals"]
                            if r["policy_mode"] == algo_modes[0]
                            and val_base <= int(r["env_seed"]) < val_base + val_count]
                    if not rows:
                        continue
                    by_step = defaultdict(list)
                    for r in rows:
                        by_step[r["step"]].append(r)
                    ks = sorted(by_step)
                    vals = []
                    for k in (ks[0], ks[-1]):
                        recs = by_step[k]
                        if key == "success":
                            vals.append(sum(r["success"] for r in recs) / len(recs))
                        else:
                            vals.append(mean([r["return"] for r in recs]))
                    first_last.append(tuple(vals))
                if len(first_last) == expect:
                    if key == "success":
                        a_txt = f"{100 * mean([a for a, _ in first_last]):.1f}%"
                        b_txt = f"{100 * mean([b for _, b in first_last]):.1f}%"
                    else:
                        a_txt = f"{mean([a for a, _ in first_last]):.3f}"
                        b_txt = f"{mean([b for _, b in first_last]):.3f}"
                    lines.append(
                        f"- 验证{key_name}[{algo_modes[0]}]：首次 {a_txt} → "
                        f"末次 {b_txt}（5 种子均值）")
            lines.append("")
        lines.append("")

    lines.append("## 问题清单")
    lines.append("")
    if problems:
        lines.extend(f"- {p}" for p in problems)
    else:
        lines.append("- 无：全部组文件齐备。文件完整不等于实验证据有效；失效运行仅作追溯记录，见正文与核验记录。")
    lines.append("")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines), encoding="utf-8")
    print(f"[digest] {out}")
    for p in problems:
        print(f"[incomplete] {p}", file=sys.stderr)
    return 0 if not problems else 2


if __name__ == "__main__":
    raise SystemExit(main())
