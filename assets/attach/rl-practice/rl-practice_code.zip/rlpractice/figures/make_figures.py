"""从 runs/ 生成系列文章的全部数据图。

输出：figures_out/<编号>_<名称>.png（300 DPI）+ 同名 .svg/.pdf（矢量）。

约定：
- 每张图的聚合需要“全部训练种子”；缺种子时抛 CollectError 并在报告里列出，
  不画半截曲线冒充完整结果。
- 曲线平滑窗口、误差带含义（跨种子 SD）写进图注文本与文件名旁的 meta。
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

from rlpractice.common.runlog import find_runs, read_run
from rlpractice.common.stats import mean, moving_average, std_sample

PR_ROOT = Path(__file__).resolve().parents[2]
RUNS = PR_ROOT / "runs"
OUT = PR_ROOT / "figures_out"
EXPECT_SEEDS = 5
FAMILY = ["#B31B1B", "#3B6EA5", "#4C9F70", "#B07C2A", "#7A5AA8"]

sns.set_theme(style="whitegrid", context="talk")
plt.rcParams.update({
    "font.sans-serif": ["Microsoft YaHei", "PingFang SC", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.dpi": 110,
    "savefig.dpi": 300,
})


class CollectError(RuntimeError):
    pass


def collect(env: str, algo: str, runs_root: Path | None = None, expect_seeds: int = EXPECT_SEEDS):
    """返回 {seed: run_dict}。要求 seed 0..expect-1 各恰好一个 completed 运行。"""
    runs_root = runs_root or RUNS
    dirs = find_runs(runs_root, env=env, algo=algo, status="completed")
    by_seed = {}
    for d in dirs:
        run = read_run(d)
        if algo in {"coma", "maddpg", "iddpg"} and run["manifest"]["config"].get("implementation_revision") != "policy-audit-v2":
            continue  # historical defective runs are retained, never re-certified
        s = run["manifest"]["seed"]
        # 同种子多次运行：取 manifest 结束时间最新的
        if s not in by_seed or run["manifest"]["finished_at"] > by_seed[s]["manifest"]["finished_at"]:
            by_seed[s] = run
    missing = [s for s in range(expect_seeds) if s not in by_seed]
    extra = sorted(set(by_seed) - set(range(expect_seeds)))
    if missing:
        raise CollectError(f"{env}/{algo} 缺训练种子 {missing}（已有 {sorted(by_seed)}）")
    if extra:
        # 多出的种子不参与聚合，但报告出来
        print(f"[warn] {env}/{algo} 存在额外种子 {extra}，不纳入 0-{expect_seeds-1} 聚合")
    return {s: by_seed[s] for s in range(expect_seeds)}


def _save(fig, name: str):
    OUT.mkdir(exist_ok=True)
    for ext in ("png", "svg", "pdf"):
        fig.savefig(OUT / f"{name}.{ext}", bbox_inches="tight")
    plt.close(fig)
    print(f"[fig] {name}.png/.svg/.pdf")


def _eval_matrix(run, policy_mode=None, split="validation"):
    """按独立种子区间分离验证与测试，禁止混合最后一个 step。"""
    cfg = run["manifest"]["config"]
    base = int(cfg.get("test_seed_base", 20000))
    count = int(cfg.get("test_episodes", 100))
    if split == "test":
        rows = [r for r in run["evals"] if base <= int(r["env_seed"]) < base + count]
    elif split == "validation":
        val_base = int(cfg.get("val_seed_base", 10000))
        val_count = int(cfg.get("eval_episodes", 20))
        rows = [r for r in run["evals"] if val_base <= int(r["env_seed"]) < val_base + val_count]
    else:
        raise ValueError(split)
    if policy_mode is not None:
        rows = [r for r in rows if r["policy_mode"] == policy_mode]
    by_step = defaultdict(list)
    for r in rows:
        by_step[r["step"]].append(r)
    return dict(sorted(by_step.items()))


def _eval_curve(run, policy_mode=None, key="success"):
    """[(step, value)]：每个评估点的成功率/掉崖率/平均回报。"""
    out = []
    for step, recs in _eval_matrix(run, policy_mode).items():
        if key == "success":
            v = sum(r["success"] for r in recs) / len(recs)
        elif key == "fell":
            v = sum(r["fell"] for r in recs) / len(recs)
        elif key == "return":
            v = mean([r["return"] for r in recs])
        else:
            raise ValueError(key)
        out.append((step, v))
    return out


def _final_test(run, policy_mode):
    """最终评估点（最大 step）在指定模式下的逐局记录。"""
    m = _eval_matrix(run, policy_mode, split="test")
    if not m:
        raise CollectError(f"{run['dir']} 无 policy_mode={policy_mode} 的评估记录")
    last_step = max(m)
    return m[last_step]


def align_curves(curves, n=60):
    """把多条 (step, value) 曲线对齐到共同步长区间后插值。

    REINFORCE 只在回合结束、COMA 只在批次结束时做评估，各种子的评估点
    步长不完全一致；直接按步长相等聚合会失败。这里取所有曲线步长区间的
    交集做线性插值，不外推、不截短任一曲线。
    """
    if len(curves) == 0:
        raise CollectError("没有可对齐的曲线")
    lo = max(c[0][0] for c in curves)
    hi = min(c[-1][0] for c in curves)
    if hi <= lo:
        raise CollectError("各曲线步长区间无交集")
    grid = np.linspace(lo, hi, n)
    mat = np.vstack([np.interp(grid,
                               [p[0] for p in c],
                               [p[1] for p in c]) for c in curves])
    return grid, mat


# ---------------------------------------------------------------- 图 1-3：悬崖
def fig_cliff_curves():
    algos = ["qlearning", "sarsa"]
    fig, ax = plt.subplots(figsize=(9, 5.5))
    for i, algo in enumerate(algos):
        runs = collect("cliff", algo)
        curves = []
        for s, run in runs.items():
            eps = run["episodes"]
            x = [e["env_steps"] for e in eps]
            y = moving_average([e["return"] for e in eps], 200)
            ax.plot(x, y, color=FAMILY[i], alpha=0.18, lw=1)
            curves.append(np.interp(np.arange(0, max(x), 1000), x, y))
        arr = np.vstack(curves)  # 5 seeds × T
        xs = np.arange(0, arr.shape[1]) * 1000
        ax.plot(xs, arr.mean(0), color=FAMILY[i], lw=2.4, label=algo)
        ax.fill_between(xs, arr.mean(0) - arr.std(0, ddof=1),
                        arr.mean(0) + arr.std(0, ddof=1), color=FAMILY[i], alpha=0.16)
    ax.set_xlabel("环境步")
    ax.set_ylabel("回合回报（滑动均值，窗口 200 局）")
    ax.set_title("悬崖变体：Q-learning 与 SARSA 的学习曲线（5 种子，mean ± SD）")
    ax.legend(frameon=False)
    _save(fig, "01_cliff_curves")


def _draw_policy(ax, q, title):
    from rlpractice.envs.cliff import CLIFF, COLS, GOAL, ROWS, ACTION_NAMES, to_cell
    arrows = {0: (0, 0.35), 1: (0, -0.35), 2: (-0.35, 0), 3: (0.35, 0)}
    for s in range(ROWS * COLS):
        r, c = to_cell(s)
        x, y = c, ROWS - 1 - r
        if (r, c) == GOAL:
            ax.add_patch(plt.Rectangle((x - .4, y - .4), .8, .8, color="#4C9F70", alpha=.85))
            ax.text(x, y, "G", ha="center", va="center", color="white", fontsize=13)
            continue
        if (r, c) in CLIFF:
            ax.add_patch(plt.Rectangle((x - .4, y - .4), .8, .8, color="#B31B1B", alpha=.8))
            ax.text(x, y, "▓", ha="center", va="center", color="white")
            continue
        a = int(np.argmax(q[s]))
        dx, dy = arrows[a]
        ax.arrow(x, y, dx, dy, head_width=.16, head_length=.1, fc="#222", ec="#222")
    ax.set_xlim(-.6, COLS - .4); ax.set_ylim(-.6, ROWS - .4)
    ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([])
    ax.set_title(title)


def fig_cliff_policy():
    algos = ["qlearning", "sarsa"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.6))
    for ax, algo in zip(axes, algos):
        run = collect("cliff", algo)[0]
        qpath = run["dir"] / "checkpoints"
        qs = list(qpath.glob("*.npz"))
        if not qs:
            raise CollectError(f"{algo} 无 Q 表 checkpoint：{qpath}")
        data = np.load(qs[0])
        key = "q" if "q" in data else list(data.files)[0]
        _draw_policy(ax, data[key], f"{algo}（greedy 贪心策略，seed0）")
    fig.suptitle("训练后的贪心策略：短但险 vs 长但稳")
    _save(fig, "02_cliff_policy")


def fig_cliff_eval():
    algos = ["qlearning", "sarsa"]
    modes = ["greedy", "stochastic"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    w = 0.36
    xs = np.arange(len(algos))
    for mi, mode in enumerate(modes):
        for ai, algo in enumerate(algos):
            runs = collect("cliff", algo)
            ret_means, fell_rates = [], []
            for run in runs.values():
                recs = _final_test(run, mode)
                ret_means.append(mean([r["return"] for r in recs]))
                fell_rates.append(sum(r["fell"] for r in recs) / len(recs))
            x = xs[ai] + (mi - 0.5) * w
            axes[0].bar(x, mean(ret_means), w, yerr=std_sample(ret_means),
                        color=FAMILY[mi], alpha=.85, capsize=4,
                        label=mode if ai == 0 else None)
            axes[1].bar(x, 100 * mean(fell_rates), w, yerr=100 * std_sample(fell_rates),
                        color=FAMILY[mi], alpha=.85, capsize=4,
                        label=mode if ai == 0 else None)
    for ax, ttl, yl in ((axes[0], "最终测试：平均回报", "return"),
                        (axes[1], "最终测试：掉崖率", "%")):
        ax.set_xticks(xs); ax.set_xticklabels(algos)
        ax.set_title(ttl + "（100 局 × 5 种子，mean ± SD）")
        ax.set_ylabel(yl)
        ax.legend(frameon=False)
    _save(fig, "03_cliff_eval_modes")


# ------------------------------------------------------------ 图 4-5：CartPole
def fig_cartpole_curves():
    algos = ["dqn", "reinforce", "a2c", "ppo"]
    fig, ax = plt.subplots(figsize=(10, 5.8))
    for i, algo in enumerate(algos):
        runs = collect("cartpole", algo)
        curves = [np.array(_eval_curve(run, "greedy", key="success"))
                  for run in runs.values()]
        grid, mat = align_curves(curves)
        ax.plot(grid, mat.mean(0), lw=2.4, color=FAMILY[i], label=algo)
        ax.fill_between(grid, mat.mean(0) - mat.std(0, ddof=1),
                        mat.mean(0) + mat.std(0, ddof=1), color=FAMILY[i], alpha=.16)
    ax.set_xlabel("环境步")
    ax.set_ylabel("验证成功率（每点 20 局）")
    ax.set_title("CartPole-v1：四种方法的验证成功率（5 种子，mean ± SD）")
    ax.legend(frameon=False, ncol=2)
    _save(fig, "04_cartpole_curves")


def fig_ppo_diag():
    runs = collect("cartpole", "ppo")
    steps, kl, cf = [], [], []
    for run in runs.values():
        ev = [e for e in run["manifest"].get("events", []) if e.get("name") == "ppo_diag"]
        for e in ev:
            steps.append(e["step"]); kl.append(e["approx_kl"]); cf.append(e["clip_frac"])
    if not steps:
        raise CollectError("ppo 无 ppo_diag 事件")
    order = np.argsort(steps)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(np.array(steps)[order], np.array(kl)[order], "o-", label="approx_kl", color=FAMILY[0])
    ax2 = ax.twinx()
    ax2.plot(np.array(steps)[order], np.array(cf)[order], "s--", label="clip_frac", color=FAMILY[1])
    ax.set_xlabel("环境步"); ax.set_ylabel("approx_kl")
    ax2.set_ylabel("clip_frac")
    ax.set_title("PPO：策略更新诊断（跨种子散点，越界即发散信号）")
    fig.legend(loc="lower left", frameon=False)
    _save(fig, "05_ppo_diag")


# ------------------------------------------------------------ 图 6-8：MARL
def fig_corridor_curves():
    algos = ["iql", "vdn", "qmix", "coma"]
    fig, ax = plt.subplots(figsize=(10, 5.8))
    for i, algo in enumerate(algos):
        runs = collect("corridor", algo)
        curves = [np.array(_eval_curve(run, "greedy", key="success"))
                  for run in runs.values()]
        grid, mat = align_curves(curves)
        ax.plot(grid, mat.mean(0), lw=2.4, color=FAMILY[i], label=algo)
        ax.fill_between(grid, mat.mean(0) - mat.std(0, ddof=1),
                        mat.mean(0) + mat.std(0, ddof=1), color=FAMILY[i], alpha=.16)
    ax.set_xlabel("联合环境步")
    ax.set_ylabel("验证成功率（每点 20 局）")
    ax.set_title("走廊协作：IQL／VDN／QMIX／COMA（5 种子，同预算，mean ± SD）")
    ax.legend(frameon=False, ncol=2)
    _save(fig, "06_corridor_curves")


def fig_riddle_ceiling():
    algos = ["commnet", "commnet_nomsg", "iql"]
    labels = {"commnet": "通信（CommNet 式 + VDN）", "commnet_nomsg": "等名义参数零消息", "iql": "独立学习"}
    fig, ax = plt.subplots(figsize=(10, 5.8))
    for i, algo in enumerate(algos):
        runs = collect("riddle", algo)
        curves = [np.array(_eval_curve(run, "greedy", key="success"))
                  for run in runs.values()]
        grid, mat = align_curves(curves)
        ax.plot(grid, mat.mean(0), lw=2.4, color=FAMILY[i], label=labels[algo])
        ax.fill_between(grid, mat.mean(0) - mat.std(0, ddof=1),
                        mat.mean(0) + mat.std(0, ddof=1), color=FAMILY[i], alpha=.16)
    ax.axhline(0.5, color="#888", ls=":", lw=1.5)
    ax.text(0.02, 0.505, "50%：无通信上限", transform=ax.get_yaxis_transform(), color="#666")
    ax.set_xlabel("联合环境步")
    ax.set_ylabel("验证成功率（每点 20 局）")
    ax.set_title("开关谜题：通信是否突破 50% 上限（5 种子，mean ± SD）")
    ax.legend(frameon=False)
    _save(fig, "07_riddle_ceiling")


def fig_nav_returns():
    algos = ["maddpg", "iddpg"]
    labels = {"maddpg": "MADDPG（集中式 critic）", "iddpg": "IDDPG（各看各的）"}
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.2))
    for i, algo in enumerate(algos):
        runs = collect("nav2d", algo)
        curves = []
        for run in runs.values():
            eps = run["episodes"]
            x = np.array([e["env_steps"] for e in eps], dtype=float)
            y = np.array(moving_average([e["return"] for e in eps], 50))
            curves.append(np.interp(np.arange(0, x[-1], 500), x, y))
        T = min(len(c) for c in curves)
        arr = np.vstack([c[:T] for c in curves])
        xs = np.arange(T) * 500
        axes[0].plot(xs, arr.mean(0), lw=2.3, color=FAMILY[i], label=labels[algo])
        axes[0].fill_between(xs, arr.mean(0) - arr.std(0, ddof=1),
                             arr.mean(0) + arr.std(0, ddof=1), color=FAMILY[i], alpha=.16)
        # 最终测试回报分布（MADDPG/IDDPG 的最终评估是贪心策略）
        rets = []
        for run in runs.values():
            recs = _final_test(run, "greedy")
            rets.append(mean([r["return"] for r in recs]))
        axes[1].bar(i, mean(rets), color=FAMILY[i], alpha=.9, yerr=std_sample(rets), capsize=5)
    axes[0].set_xlabel("联合环境步"); axes[0].set_ylabel("回合回报（滑动均值 50 局）")
    axes[0].set_title("训练曲线（5 种子，mean ± SD）"); axes[0].legend(frameon=False)
    axes[1].set_xticks([0, 1]); axes[1].set_xticklabels([labels[a] for a in algos], rotation=12)
    axes[1].set_title("最终测试：每种子 100 局\n（跨种子 mean ± SD）")
    axes[1].set_ylabel("回合回报")
    fig.tight_layout()
    _save(fig, "08_nav_returns")


def fig_ppo_budget_gap():
    """历史 PPO episodes.csv 取证：环境步走满预算，累计局长和因 rollout 边界清零而缺账。"""
    import csv as _csv
    cands = sorted((RUNS / "cartpole" / "ppo").glob("seed0_*/episodes.csv"))
    if not cands:
        raise CollectError("cartpole/ppo/seed0 无 episodes.csv")
    rows = list(_csv.DictReader(cands[-1].open(encoding="utf-8")))
    if not rows:
        raise CollectError(f"{cands[-1]} 无数据行")
    ep = np.arange(1, len(rows) + 1)
    env_cum = np.array([int(r["env_steps"]) for r in rows], dtype=float)
    len_cum = np.cumsum([int(r["length"]) for r in rows]).astype(float)
    gap = int(env_cum[-1] - len_cum[-1])
    if gap <= 0:
        raise CollectError(f"该运行无记账缺口（gap={gap}），不符合取证图预期")

    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.fill_between(ep, len_cum, env_cum, color=FAMILY[0], alpha=.14,
                    label=f"缺口 {gap} 步（rollout 边界处被清零）")
    ax.plot(ep, env_cum, lw=2.2, color=FAMILY[1],
            label=f"累计环境步（末值 {int(env_cum[-1])}，预算走满）")
    ax.plot(ep, len_cum, lw=2.2, color=FAMILY[0],
            label=f"累计局长和（末值 {int(len_cum[-1])}）")
    first = int(np.argmax(env_cum - len_cum > 0))
    ax.annotate(f"首个 512 边界处开始分叉\n（回合 {first + 1}，缺 "
                f"{int(env_cum[first] - len_cum[first])} 步）",
                xy=(ep[first], env_cum[first]), xytext=(ep[first] + 350, 42000),
                arrowprops=dict(arrowstyle="->", color="#555"), fontsize=11, color="#333")
    ax.set_xlabel("训练回合（episodes.csv 行序）")
    ax.set_ylabel("累计步数")
    ax.set_title("历史 PPO 记账取证：环境步走满 100000，累计局长和缺 "
                 f"{gap} 步（seed0）")
    ax.legend(frameon=False, loc="upper left", fontsize=10)
    fig.tight_layout()
    _save(fig, "09_ppo_budget_gap")


FIGURES = [
    ("01_cliff_curves", fig_cliff_curves),
    ("02_cliff_policy", fig_cliff_policy),
    ("03_cliff_eval_modes", fig_cliff_eval),
    ("04_cartpole_curves", fig_cartpole_curves),
    ("05_ppo_diag", fig_ppo_diag),
    ("06_corridor_curves", fig_corridor_curves),
    ("07_riddle_ceiling", fig_riddle_ceiling),
    ("08_nav_returns", fig_nav_returns),
    ("09_ppo_budget_gap", fig_ppo_budget_gap),
]


def build_all(argv=None) -> int:
    global RUNS
    p = argparse.ArgumentParser(description="生成系列数据图（只读 runs/）")
    p.add_argument("--only", nargs="*", default=None, help="只生成指定图名")
    p.add_argument("--runs-root", default=str(RUNS))
    args = p.parse_args(argv)
    RUNS = Path(args.runs_root)
    ok, skipped = [], []
    for name, fn in FIGURES:
        if args.only and name not in args.only:
            continue
        try:
            fn()
            ok.append(name)
        except CollectError as e:
            skipped.append((name, str(e)))
            print(f"[skip] {name}: {e}", file=sys.stderr)
    print(f"\n完成 {len(ok)} 张；跳过 {len(skipped)} 张")
    for n, why in skipped:
        print(f"  - {n}: {why}")
    report = OUT / "figure_report.json"
    OUT.mkdir(exist_ok=True)
    report.write_text(json.dumps(
        {"generated": ok, "skipped": [{"name": n, "reason": w} for n, w in skipped]},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if not skipped else 2


if __name__ == "__main__":
    raise SystemExit(build_all())
