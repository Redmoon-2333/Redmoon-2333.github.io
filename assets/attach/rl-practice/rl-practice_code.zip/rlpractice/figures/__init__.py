"""绘图入口：`python -m rlpractice.figures`。

硬约束：只读取 runs/ 下的日志与 manifest，绝不导入算法模块、绝不训练；
种子不齐时明确报错跳过，不静默截短或补造数据。
"""
from __future__ import annotations

import sys


def main(argv=None) -> int:
    from .make_figures import build_all
    return build_all(argv)


if __name__ == "__main__":
    raise SystemExit(main())
