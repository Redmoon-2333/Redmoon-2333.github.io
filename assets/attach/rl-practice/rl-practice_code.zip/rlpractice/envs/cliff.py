"""悬崖行走（终止式变体）——移植自源项目 `强化学习入门\\code\\01_gridworld_qlearning.py`。

与 Sutton & Barto 标准 CliffWalking 的差异（正文必须写明）：
- 标准版掉崖后回到起点继续走；本变体掉崖即回合结束（terminated）。
- 本实现额外区分 terminated（到达目标/掉崖，真实终止）与 truncated（步数上限）。

奖励：普通步 -0.04，掉崖 -1（终止），到达目标 +1（终止）。
"""
from __future__ import annotations

import numpy as np

ROWS, COLS = 4, 6
START = (3, 0)
GOAL = (3, 5)
CLIFF = {(3, 1), (3, 2), (3, 3), (3, 4)}
ACTIONS = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 上 下 左 右
ACTION_NAMES = ["↑", "↓", "←", "→"]
N_S = ROWS * COLS
N_A = len(ACTIONS)
STEP_COST = -0.04
CLIFF_PENALTY = -1.0
GOAL_REWARD = 1.0


def to_id(cell) -> int:
    return cell[0] * COLS + cell[1]


def to_cell(state_id: int):
    return divmod(int(state_id), COLS)


class CliffEnv:
    """gym 风格接口：reset(seed) -> (obs, info)；step(a) -> (obs, r, term, trunc, info)。

    obs 是 0..23 的整数状态编号（表格法直接可用）。
    """

    N_ACTIONS = N_A
    N_STATES = N_S
    MAX_STEPS_DEFAULT = 100

    def __init__(self, max_steps: int = MAX_STEPS_DEFAULT, seed: int = 0):
        assert max_steps > 0
        self.max_steps = int(max_steps)
        self.rng = np.random.default_rng(seed)
        self.t = 0
        self.state = to_id(START)

    def reset(self, seed=None):
        if seed is not None:
            self.rng = np.random.default_rng(int(seed))
        self.t = 0
        self.state = to_id(START)
        return int(self.state), {}

    def step(self, action: int):
        if not (0 <= int(action) < N_A):
            raise ValueError(f"invalid action {action}")
        r, c = to_cell(self.state)
        dr, dc = ACTIONS[int(action)]
        nr = r + dr if 0 <= r + dr < ROWS else r
        nc = c + dc if 0 <= c + dc < COLS else c
        ns = to_id((nr, nc))
        self.t += 1
        info = {"fell": False, "success": False}

        if (nr, nc) == GOAL:
            self.state = ns
            return ns, GOAL_REWARD, True, False, {**info, "success": True}
        if (nr, nc) in CLIFF:
            self.state = ns
            return ns, CLIFF_PENALTY, True, False, {**info, "fell": True}

        self.state = ns
        truncated = self.t >= self.max_steps
        return ns, STEP_COST, False, truncated, info

    # ---- 辅助（绘图/测试用） ----
    @staticmethod
    def is_cliff(state_id: int) -> bool:
        return to_cell(state_id) in CLIFF

    @staticmethod
    def is_goal(state_id: int) -> bool:
        return to_cell(state_id) == GOAL

    @staticmethod
    def render_policy(q_or_policy) -> str:
        """把 24 状态策略/Q 表画成 4x6 字符图。"""
        cells = []
        for s in range(N_S):
            if to_cell(s) == GOAL:
                cells.append("G")
            elif to_cell(s) in CLIFF:
                cells.append("▓")
            else:
                a = int(np.argmax(q_or_policy[s])) if q_or_policy[s].ndim == 1 else int(q_or_policy[s])
                cells.append(ACTION_NAMES[a])
        return "\n".join(" ".join(cells[r * COLS:(r + 1) * COLS]) for r in range(ROWS))
