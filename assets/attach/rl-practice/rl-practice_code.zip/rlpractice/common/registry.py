"""算法注册表：各算法模块通过 @register(name) 自注册，train.py 按名字调度。

register(name, defaults=None) 可携带该算法自己的默认超参；未提供时
train.py 回退读取算法所在模块的 DEFAULTS。
"""
from __future__ import annotations

import importlib
from typing import Callable, Dict, Optional

_ALGOS: Dict[str, Callable] = {}
_DEFAULTS: Dict[str, dict] = {}


def register(name: str, defaults: Optional[dict] = None):
    """装饰器：把 `run(cfg, log) -> summary` 形式的入口注册为 name。"""
    if not isinstance(name, str) or not name:
        raise ValueError("algorithm name must be a non-empty string")

    def deco(fn: Callable):
        if name in _ALGOS and _ALGOS[name] is not fn:
            raise ValueError(f"duplicate algorithm registration: {name!r}")
        _ALGOS[name] = fn
        _DEFAULTS[name] = dict(defaults) if defaults else {}
        return fn

    return deco


def get(name: str) -> Callable:
    if name not in _ALGOS:
        raise KeyError(f"unknown algorithm {name!r}; registered: {sorted(_ALGOS)}")
    return _ALGOS[name]


def get_defaults(name: str) -> dict:
    """该算法的默认配置：注册时给的优先，否则读模块级 DEFAULTS。"""
    if name not in _ALGOS:
        raise KeyError(name)
    if _DEFAULTS.get(name):
        return dict(_DEFAULTS[name])
    fn = _ALGOS[name]
    module = importlib.import_module(fn.__module__)
    return dict(getattr(module, "DEFAULTS", {}))


def names() -> list:
    return sorted(_ALGOS)
