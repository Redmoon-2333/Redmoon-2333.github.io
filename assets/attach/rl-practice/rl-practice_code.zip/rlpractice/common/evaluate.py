"""统一评估协议。

原则（对应系列第 11 章）：
- 评估环境由独立、显式的种子列表决定，与训练 RNG 完全隔离；
- 记录每一局的原始 return / 长度 / success / fell / truncated，而不是只存均值；
- policy_mode 明确标注是贪心还是保留探索，两者不混报；
- 评估函数是纯读取：不写回模型、不污染训练经验。
"""
from __future__ import annotations

from typing import Callable, Iterable, List, Sequence


def eval_episode(env, act_fn: Callable[[object], int], env_seed: int,
                 max_steps: int) -> dict:
    """跑一局并返回原始记录。env 需为 gym 风格 reset/step 接口。"""
    obs, _ = env.reset(seed=env_seed)
    ret = 0.0
    length = 0
    terminated = truncated = False
    info = {}
    while not (terminated or truncated) and length < max_steps:
        action = int(act_fn(obs))
        obs, r, terminated, truncated, info = env.step(action)
        ret += float(r)
        length += 1
    return {
        "env_seed": int(env_seed),
        "return": ret,
        "length": length,
        "success": bool(info.get("success", False)),
        "fell": bool(info.get("fell", False)),
        "truncated": bool(truncated and not terminated),
        "terminated": bool(terminated),
    }


def evaluate_policy(env, act_fn: Callable[[object], int],
                    seeds: Iterable[int], max_steps: int) -> List[dict]:
    """在固定种子列表上评估，返回逐局记录。"""
    records = [eval_episode(env, act_fn, s, max_steps) for s in seeds]
    return records


def summarize(records: Sequence[dict]) -> dict:
    """由原始记录聚合，保留明细供绘图。"""
    n = len(records)
    if n == 0:
        return {"n": 0}
    rets = [r["return"] for r in records]
    mean = sum(rets) / n
    var = sum((x - mean) ** 2 for x in rets) / (n - 1) if n > 1 else 0.0
    return {
        "n": n,
        "return_mean": mean,
        "return_std": var ** 0.5,
        "return_min": min(rets),
        "return_max": max(rets),
        "success_rate": sum(r["success"] for r in records) / n,
        "fell_rate": sum(r["fell"] for r in records) / n,
        "truncation_rate": sum(r["truncated"] for r in records) / n,
        "length_mean": sum(r["length"] for r in records) / n,
    }


def held_out_seeds(base: int, n: int) -> List[int]:
    """确定性地派生一组保留种子（评估/测试用），与训练种子空间不重叠。"""
    return [int(base + i) for i in range(n)]
