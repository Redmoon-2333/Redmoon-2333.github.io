"""运行日志：manifest + episodes.csv + evals.csv + checkpoint 目录。

设计约束（对应系列文章的实验方法论）：
- 训练、评估、绘图分离：绘图只读本目录产物，不触发训练；
- 一切正文数字可追溯：配置、依赖版本、源码指纹、种子全部落盘；
- 失败不静默：异常时 status=failed 并记录原因，已写数据保留。
"""
from __future__ import annotations

import csv
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
from typing import Iterable, Optional, Sequence

_PKG_ROOT = Path(__file__).resolve().parents[2]  # .../rl-practice

_EPISODE_FIELDS = [
    "episode", "return", "length", "env_steps", "updates", "elapsed_s",
    "terminated", "truncated",
]
_EVAL_FIELDS = [
    "step", "policy_mode", "episode", "env_seed", "return", "length",
    "success", "fell", "truncated",
]


def source_sha256(root: Path = _PKG_ROOT) -> str:
    """对 rlpractice/**/*.py 做内容指纹，落盘以便追溯代码版本。"""
    h = hashlib.sha256()
    for p in sorted(root.rglob("*.py")):
        if "__pycache__" in p.parts:
            continue
        h.update(str(p.relative_to(root)).encode("utf-8"))
        h.update(p.read_bytes())
    return h.hexdigest()


def _versions() -> dict:
    out = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }
    for mod in ("numpy", "torch", "matplotlib", "gymnasium", "seaborn", "pandas", "scipy"):
        try:
            m = __import__(mod)
            out[mod] = getattr(m, "__version__", "?")
        except Exception as e:  # 缺失也要如实记录
            out[mod] = f"unavailable: {type(e).__name__}"
    return out


class RunLogger:
    """一次训练运行的全部落盘产物。用法::

        log = RunLogger(runs_root, env="cliff", algo="qlearning",
                        seed=0, config={...})
        log.episode(i, ret, length, env_steps, updates)
        log.evaluate(step, "greedy", records)
        log.finish("completed")
    """

    def __init__(self, runs_root: Path | str, env: str, algo: str, seed: int,
                 config: dict, run_name: Optional[str] = None):
        stamp = time.strftime("%Y%m%d-%H%M%S")
        name = run_name or f"seed{seed}_{stamp}"
        self.run_dir = Path(runs_root) / env / algo / name
        self.run_dir.mkdir(parents=True, exist_ok=False)
        (self.run_dir / "checkpoints").mkdir(exist_ok=True)

        self.env = env
        self.algo = algo
        self.seed = int(seed)
        self.config = dict(config)
        self.t0 = time.time()
        self._episode_file = open(self.run_dir / "episodes.csv", "w", newline="", encoding="utf-8")
        self._episode_w = csv.DictWriter(self._episode_file, fieldnames=_EPISODE_FIELDS)
        self._episode_w.writeheader()
        self._eval_file = open(self.run_dir / "evals.csv", "w", newline="", encoding="utf-8")
        self._eval_w = csv.DictWriter(self._eval_file, fieldnames=_EVAL_FIELDS)
        self._eval_w.writeheader()
        self.manifest = {
            "schema_version": 1,
            "env": env,
            "algo": algo,
            "seed": self.seed,
            "config": self.config,
            "versions": _versions(),
            "source_sha256": source_sha256(),
            "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "finished_at": None,
            "status": "running",
            "note": "",
            "wall_seconds": None,
        }
        self._write_manifest()

    # ---------- 写入 ----------
    def _write_manifest(self):
        tmp = self.run_dir / "manifest.json.tmp"
        tmp.write_text(json.dumps(self.manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.run_dir / "manifest.json")

    def episode(self, episode: int, ret: float, length: int, env_steps: int,
                updates: int, terminated: bool, truncated: bool):
        self._episode_w.writerow({
            "episode": episode, "return": round(float(ret), 6), "length": int(length),
            "env_steps": int(env_steps), "updates": int(updates),
            "elapsed_s": round(time.time() - self.t0, 3),
            "terminated": int(bool(terminated)), "truncated": int(bool(truncated)),
        })
        self._episode_file.flush()

    def evaluate(self, step: int, policy_mode: str, records: Sequence[dict]):
        """records: 每局一个 dict，含 env_seed/return/length/success/fell/truncated。"""
        for k, r in enumerate(records):
            self._eval_w.writerow({
                "step": int(step), "policy_mode": policy_mode, "episode": k,
                "env_seed": int(r["env_seed"]), "return": round(float(r["return"]), 6),
                "length": int(r["length"]), "success": int(bool(r.get("success", False))),
                "fell": int(bool(r.get("fell", False))),
                "truncated": int(bool(r.get("truncated", False))),
            })
        self._eval_file.flush()

    def event(self, name: str, **kv):
        """补充事件（如训练异常、早停原因）追加进 manifest。"""
        self.manifest.setdefault("events", []).append(
            {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "name": name, **kv})
        self._write_manifest()

    def finish(self, status: str = "completed", note: str = ""):
        assert status in ("completed", "failed")
        self.manifest["status"] = status
        self.manifest["note"] = note
        self.manifest["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        self.manifest["wall_seconds"] = round(time.time() - self.t0, 3)
        self._write_manifest()
        self._episode_file.close()
        self._eval_file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc is not None and not self._episode_file.closed:
            self.finish("failed", f"{exc_type.__name__}: {exc}")
        return False


def read_run(run_dir: Path | str) -> dict:
    """绘图侧只用这个读取运行产物（不导入算法模块、不训练）。"""
    d = Path(run_dir)
    manifest = json.loads((d / "manifest.json").read_text(encoding="utf-8"))

    def _csv(name, ints=(), floats=()):
        p = d / name
        if not p.exists():
            return []
        rows = []
        with open(p, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                for c in ints:
                    if c in row and row[c] != "":
                        row[c] = int(row[c])
                for c in floats:
                    if c in row and row[c] != "":
                        row[c] = float(row[c])
                rows.append(row)
        return rows

    return {
        "manifest": manifest,
        "episodes": _csv("episodes.csv", ints=("episode", "length", "env_steps", "updates",
                                               "terminated", "truncated"),
                         floats=("return", "elapsed_s")),
        "evals": _csv("evals.csv", ints=("step", "episode", "env_seed", "length",
                                         "success", "fell", "truncated"),
                      floats=("return",)),
        "dir": d,
    }


def find_runs(runs_root: Path | str, env: Optional[str] = None,
              algo: Optional[str] = None, status: str = "completed") -> list:
    root = Path(runs_root)
    out = []
    if not root.exists():
        return out
    for m in sorted(root.glob("*/*/seed*/manifest.json")):
        man = json.loads(m.read_text(encoding="utf-8"))
        if env and man.get("env") != env:
            continue
        if algo and man.get("algo") != algo:
            continue
        if status and man.get("status") != status:
            continue
        out.append(m.parent)
    return out
