"""统计与曲线工具：只做纯计算，不接触文件与训练。"""
from __future__ import annotations

import math
from typing import Sequence


def mean(x: Sequence[float]) -> float:
    return sum(x) / len(x) if x else float("nan")


def std_sample(x: Sequence[float]) -> float:
    """样本标准差（ddof=1）。报告时注明是 SD，不是 SEM/CI。"""
    n = len(x)
    if n < 2:
        return float("nan")
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (n - 1))


def sem(x: Sequence[float]) -> float:
    n = len(x)
    if n < 2:
        return float("nan")
    return std_sample(x) / math.sqrt(n)


def moving_average(x: Sequence[float], window: int) -> list:
    """因果滑动平均：输出与输入等长，前 window-1 个用可用前缀均值。"""
    if window <= 1:
        return list(x)
    out, acc = [], 0.0
    from collections import deque
    q = deque()
    for v in x:
        q.append(v)
        acc += v
        if len(q) > window:
            acc -= q.popleft()
        out.append(acc / len(q))
    return out


def first_threshold_crossing(x: Sequence[float], threshold: float,
                             window: int = 1, mode: str = "above") -> int | None:
    """返回滑动均值首次跨过阈值的**窗口末端**下标；未达到返回 None（censored）。

    mode='above' 表示 >= threshold，'below' 表示 <= threshold。
    注意：必须返回 idx+window-1（窗口末端），否则会把收敛时间报早一个窗口宽度。
    """
    if mode not in ("above", "below"):
        raise ValueError(mode)
    y = moving_average(x, window)
    for i, v in enumerate(y):
        if i + 1 < window:
            continue  # 未满窗不判定
        if (mode == "above" and v >= threshold) or (mode == "below" and v <= threshold):
            return i
    return None
